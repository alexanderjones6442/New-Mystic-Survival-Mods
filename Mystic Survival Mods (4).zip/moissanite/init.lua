-- Block and Ore/Mapgen
minetest.register_node("moissanite:moissanite_block", {
	description = ("Moissanite Block"),
	tiles = {"moissanite_moissanite_block.png"},
	is_ground_content = true,
	groups = {cracky=1, level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("moissanite:moissanite_ore", {
	description = ("Moissanite Ore"),
	tiles = {"default_stone.png^moissanite_moissanite_ore.png"},
	groups = {cracky=1, level=3},
	sounds = default.node_sound_stone_defaults(),
	drop = "moissanite:moissanite_gem",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "moissanite:moissanite_ore",
	wherein        = "default:stone",
	clust_scarcity = 27 * 27 * 27,
	clust_num_ores = 3,
	clust_size     = 2,
	y_max          = -6000,
	y_min          = -20000,
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "moissanite:moissanite_ore",
	wherein        = "default:stone",
	clust_scarcity = 26 * 26 * 26,
	clust_num_ores = 4,
	clust_size     = 3,
	y_max          = -15000,
	y_min          = -28000,
})

-- Tools
minetest.register_tool("moissanite:moissanite_sword", {
	description = ("Moissanite Sword"),
	inventory_image = "moissanite_moissanite_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.325, [2]=0.3, [3]=0.2}, uses=2860, maxlevel=3},
		},
		damage_groups = {fleshy=26},
	},
	sound = {breaks = default_tool_breaks},
	groups = {sword = 1},
})

minetest.register_tool("moissanite:moissanite_pickaxe", {
	description = ("Moissanite Pickaxe"),
	inventory_image = "moissanite_moissanite_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			cracky={times={[1]=0.325, [2]=0.3, [3]=0.2}, uses=2860, maxlevel=3},
		},
		damage_groups = {fleshy=24},
	},
	sound = {breaks = default_tool_breaks},
	groups = {pickaxe = 1},
})

minetest.register_tool("moissanite:moissanite_axe", {
	description = ("Moissanite Axe"),
	inventory_image = "moissanite_moissanite_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.325, [2]=0.3, [3]=0.2}, uses=2860, maxlevel=3},
		},
		damage_groups = {fleshy=25},
	},
	sound = {breaks = default_tool_breaks},
	groups = {axe = 1},
})

minetest.register_tool("moissanite:moissanite_shovel", {
	description = ("Moissanite Shovel"),
	inventory_image = "moissanite_moissanite_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.325, [2]=0.3, [3]=0.2}, uses=2860, maxlevel=3},
		},
		damage_groups = {fleshy=23},
	},
	sound = {breaks = default_tool_breaks},
	groups = {shovel = 1},
})

-- Gem
minetest.register_craftitem("moissanite:moissanite_gem", {
	description = ("Moissanite Pearl"),
	inventory_image = "moissanite_moissanite_pearl.png"
})

-- Crafts
minetest.register_craft({
	output = "moissanite:moissanite_block",
	recipe = {
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem", "moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem", "moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem", "moissanite:moissanite_gem"}
	},
})

minetest.register_craft({
	output = "moissanite:moissanite_gem 9",
	recipe = {
		{"moissanite:moissanite_block"}
	},
})

minetest.register_craft({
	output = "moissanite:moissanite_sword",
	recipe = {
		{"moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem"},
		{"group:stick"}
	},
})

minetest.register_craft({
	output = "moissanite:moissanite_pickaxe",
	recipe = {
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem", "moissanite:moissanite_gem"},
		{"", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "moissanite:moissanite_axe",
	recipe = {
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem", "group:stick"},
		{"", "group:stick"}
	},
})

minetest.register_craft({
	output = "moissanite:moissanite_shovel",
	recipe = {
		{"moissanite:moissanite_gem"},
		{"group:stick"},
		{"group:stick"}
	},
})

minetest.register_craft({
	output = "moissanite:moissanite_helmet",
	recipe = {
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem", "moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem","", "moissanite:moissanite_gem"}
	},
})

minetest.register_craft({
	output = "moissanite:moissanite_chestplate",
	recipe = {
		{"moissanite:moissanite_gem", "", "moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem", "moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem", "moissanite:moissanite_gem"}
	},
})

minetest.register_craft({
	output = "moissanite:moissanite_leggings",
	recipe = {
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem", "moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem", "", "moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem", "", "moissanite:moissanite_gem"}
	},
})

minetest.register_craft({
	output = "moissanite:moissanite_boots",
	recipe = {
		{"moissanite:moissanite_gem", "", "moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem", "", "moissanite:moissanite_gem"}
	},
})

minetest.register_craft({
	output = "moissanite:moissanite_shield",
	recipe = {
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem", "moissanite:moissanite_gem"},
		{"moissanite:moissanite_gem", "moissanite:moissanite_gem", "moissanite:moissanite_gem"},
		{"", "moissanite:moissanite_gem", ""}
	},
})


-- Armor Registration
if minetest.get_modpath("3d_armor") then
	armor:register_armor("moissanite:moissanite_helmet", {
		description = ("Moissanite Helmet"),
		inventory_image = "moissanite_moissanite_helmet_inv.png",
		groups = {armor_head=1, armor_heal=33, armor_use=130, armor_fire=1},
		armor_groups = {fleshy=9},
		damage_groups = {cracky=2, snappy=1, level=34},
	})

	armor:register_armor("moissanite:moissanite_chestplate", {
		description = ("Moissanite Chestplate"),
		inventory_image = "moissanite_moissanite_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=35, armor_use=130, armor_fire=1},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=2, snappy=1, level=36},
	})

	armor:register_armor("moissanite:moissanite_leggings", {
		description = ("Moissanite Leggings"),
		inventory_image = "moissanite_moissanite_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=34, armor_use=130, armor_fire=1},
		armor_groups = {fleshy=10},
		damage_groups = {cracky=2, snappy=1, level=35},
	})

	armor:register_armor("moissanite:moissanite_boots", {
		description = ("Moissanite Boots"),
		inventory_image = "moissante_moissanite_boots_inv.png",
		groups = {armor_feet=1, armor_heal=32, armor_use=130, armor_fire=1, physics_speed=1},
		armor_groups = {fleshy=8},
		damage_groups = {cracky=2, snappy=1, level=33},
	})
end