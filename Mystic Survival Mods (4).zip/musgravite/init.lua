-- Block and Ore/Mapgen
minetest.register_node("musgravite:musgravite_block", {
	description = ("Musgravite Block"),
	tiles = {"musgravite_musgravite_block.png"},
	is_ground_content = true,
	groups = {cracky=1, level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("musgravite:musgravite_ore", {
	description = ("Musgravite Ore"),
	tiles = {"default_stone.png^musgravite_musgravite_ore.png"},
	groups = {cracky=1, level=3},
	sounds = default.node_sound_stone_defaults(),
	drop = "musgravite:musgravite_gem",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "musgravite:musgravite_ore",
	wherein        = "default:stone",
	clust_scarcity = 30 * 30 * 30,
	clust_num_ores = 2,
	clust_size     = 1,
	y_max          = -8000,
	y_min          = -15000,
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "musgravite:musgravite_ore",
	wherein        = "default:stone",
	clust_scarcity = 28* 28 * 28,
	clust_num_ores = 3,
	clust_size     = 2,
	y_max          = -20000,
	y_min          = -28000,
})

-- Tools
minetest.register_tool("musgravite:musgravite_sword", {
	description = ("Musgravite Sword"),
	inventory_image = "musgravite_musgravite_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.31, [2]=0.27, [3]=0.19}, uses=3500, maxlevel=3},
		},
		damage_groups = {fleshy=35},
	},
	sound = {breaks = default_tool_breaks},
	groups = {sword = 1},
})

minetest.register_tool("musgravite:musgravite_pickaxe", {
	description = ("Musgravite Pickaxe"),
	inventory_image = "musgravite_musgravite_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			cracky={times={[1]=0.31, [2]=0.27, [3]=0.19}, uses=3500, maxlevel=3},
		},
		damage_groups = {fleshy=33},
	},
	sound = {breaks = default_tool_breaks},
	groups = {pickaxe = 1},
})

minetest.register_tool("musgravite:musgravite_axe", {
	description = ("Musgravite Axe"),
	inventory_image = "musgravite_musgravite_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.31, [2]=0.27, [3]=0.19}, uses=3500, maxlevel=3},
		},
		damage_groups = {fleshy=34},
	},
	sound = {breaks = default_tool_breaks},
	groups = {axe = 1},
})

minetest.register_tool("musgravite:musgravite_shovel", {
	description = ("Musgravite Shovel"),
	inventory_image = "musgravite_musgravite_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.31, [2]=0.27, [3]=0.19}, uses=3500, maxlevel=3},
		},
		damage_groups = {fleshy=32},
	},
	sound = {breaks = default_tool_breaks},
	groups = {shovel = 1},
})

-- Gem
minetest.register_craftitem("musgravite:musgravite_gem", {
	description = ("Musgravite Gem"),
	inventory_image = "musgravite_musgravite_gem.png"
})

-- Crafts
minetest.register_craft({
	output = "musgravite:musgravite_block",
	recipe = {
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem", "musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem", "musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem", "musgravite:musgravite_gem"}
	},
})

minetest.register_craft({
	output = "musgravite:musgravite_gem 9",
	recipe = {
		{"musgravite:musgravite_block"}
	},
})

minetest.register_craft({
	output = "musgravite:musgravite_sword",
	recipe = {
		{"musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem"},
		{"group:stick"}
	},
})

minetest.register_craft({
	output = "musgravite:musgravite_pickaxe",
	recipe = {
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem", "musgravite:musgravite_gem"},
		{"", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "musgravite:musgravite_axe",
	recipe = {
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem", "group:stick"},
		{"", "group:stick"}
	},
})

minetest.register_craft({
	output = "musgravite:musgravite_shovel",
	recipe = {
		{"musgravite:musgravite_gem"},
		{"group:stick"},
		{"group:stick"}
	},
})

minetest.register_craft({
	output = "musgravite:musgravite_helmet",
	recipe = {
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem", "musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem","", "musgravite:musgravite_gem"}
	},
})

minetest.register_craft({
	output = "musgravite:musgravite_chestplate",
	recipe = {
		{"musgravite:musgravite_gem", "", "musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem", "musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem", "musgravite:musgravite_gem"}
	},
})

minetest.register_craft({
	output = "musgravite:musgravite_leggings",
	recipe = {
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem", "musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem", "", "musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem", "", "musgravite:musgravite_gem"}
	},
})

minetest.register_craft({
	output = "musgravite:musgravite_boots",
	recipe = {
		{"musgravite:musgravite_gem", "", "musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem", "", "musgravite:musgravite_gem"}
	},
})

minetest.register_craft({
	output = "musgravite:musgravite_shield",
	recipe = {
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem", "musgravite:musgravite_gem"},
		{"musgravite:musgravite_gem", "musgravite:musgravite_gem", "musgravite:musgravite_gem"},
		{"", "musgravite:musgravite_gem", ""}
	},
})


-- Armor Registration
if minetest.get_modpath("3d_armor") then
	armor:register_armor("musgravite:musgravite_helmet", {
		description = ("Musgravite Helmet"),
		inventory_image = "musgravite_musgravite_helmet_inv.png",
		groups = {armor_head=1, armor_heal=33, armor_use=130, armor_fire=1},
		armor_groups = {fleshy=9},
		damage_groups = {cracky=2, snappy=1, level=34},
	})

	armor:register_armor("musgravite:musgravite_chestplate", {
		description = ("Musgravite Chestplate"),
		inventory_image = "musgravite_musgravite_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=23, armor_use=130, armor_fire=1},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=2, snappy=1, level=36},
	})

	armor:register_armor("musgravite:musgravite_leggings", {
		description = ("Musgravite Leggings"),
		inventory_image = "musgravite_musgravite_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=22, armor_use=130, armor_fire=1},
		armor_groups = {fleshy=10},
		damage_groups = {cracky=2, snappy=1, level=35},
	})

	armor:register_armor("musgravite:musgravite_boots", {
		description = ("Musgravite Boots"),
		inventory_image = "musgravite_musgravite_boots_inv.png",
		groups = {armor_feet=1, armor_heal=20, armor_use=130, armor_fire=1, physics_speed=1},
		armor_groups = {fleshy=8},
		damage_groups = {cracky=2, snappy=1, level=33},
	})
end