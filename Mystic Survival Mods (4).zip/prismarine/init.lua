-- Blocks and Ore

minetest.register_node("prismarine:prismarine_ore", {
	description = ("Prismarine Ore"),
	tiles = {"default_stone.png^prismarine_prismarine_ore.png"},
	is_ground_content = true,
	groups = {cracky = 3, level = 1},
	sounds = default.node_sound_stone_defaults(),
	drop = "prismarine:prismarine_shard"
})

minetest.register_node("prismarine:prismarine_block", {
	description = ("Prismarine Block"),
	tiles = {"prismarine_prismarine_block.png"},
	groups = {cracky = 2, level = 1},
	light_source = 2,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("prismarine:prismarine_brick", {
	description = ("Prismarine Brick"),
	tiles = {"prismarine_prismarine_brick.png"},
	groups = {cracky = 2, level = 1},
	light_source = 5,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craftitem("prismarine:prismarine_shard", {
	description = ("Prismarine Shard"),
	inventory_image = "prismarine_prismarine_shard.png"
})

-- Crafts

minetest.register_craft({
	output = "prismarine:prismarine_block",
	recipe = {
		{"prismarine:prismarine_shard", "prismarine:prismarine_shard", "prismarine:prismarine_shard"},
		{"prismarine:prismarine_shard", "prismarine:prismarine_shard", "prismarine:prismarine_shard"},
		{"prismarine:prismarine_shard", "prismarine:prismarine_shard", "prismarine:prismarine_shard"}
	},
})

minetest.register_craft({
	output = "prismarine:prismarine_brick",
	recipe = {
		{"prismarine:prismarine_block", "prismarine:prismarine_block"},
		{"prismarine:prismarine_block", "prismarine:prismarine_block"}
	},
})

minetest.register_craft({
	output = "prismarine:prismarine_shard 9",
	recipe = {
		{"prismarine:prismarine_block"}
	},
})

-- Ore Mapgen
minetest.register_ore({
	ore_type       = "scatter",
	ore            = "prismarine:prismarine_ore",
	wherein        = "default:stone",
	clust_scarcity = 10 * 10 * 10,
	clust_num_ores = 4,
	clust_size     = 4,
	y_max          = -20,
	y_min          = -20000,
})