-- Blocks
minetest.register_node("opal:opal_ore", {
	description = ("Opal Ore"),
	tiles = {"default_stone.png^opal_opal_ore.png"},
	is_ground_content = true,
	groups = {cracky = 2, level = 1},
	sounds = default.node_sound_stone_defaults(),
	drop = "opal:opal",
})

minetest.register_node("opal:opal_block", {
	description = ("Opal Block"),
	tiles = {"opal_opal_block.png"},
	groups = {cracky = 3, level = 2},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("opal:opal_glass", {
	description = ("Opal Glass"),
	drawtype = "glasslike_framed_optional",
	paramtype = "light",
	sunlight_propagates = true,
	tiles = {"opal_opal_glass.png"},
	groups = {cracky = 1, level = 1},
	sounds = default.node_sound_glass_defaults(),
	light_source = 30,
})

minetest.register_node("opal:opal_brick", {
	description = ("Opal Brick"),
	tiles = {"opal_opal_brick.png"},
	groups = {cracky = 2, level = 2},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("opal:opal_pillar", {
	description = ("Opal Pillar"),
	tiles = {"opal_opal_pillar_top.png", "opal_opal_pillar_top.png", "opal_opal_pillar.png"},
	groups = {cracky = 2, level = 2},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("opal:opal_pillar_cracked", {
	description = ("Cracked Opal Pillar"),
	tiles = {"opal_opal_pillar_cracked_top.png", "opal_opal_pillar_cracked_top.png", "opal_opal_pillar_cracked.png"},
	paramtype2 = "wallmounted",
	groups = {cracky = 2, level = 2},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("opal:opal_brick_cracked", {
	description = ("Cracked Opal Brick"),
	tiles = {"opal_opal_brick_cracked.png"},
	groups = {cracky = 2, level = 2},
	sounds = default.node_sound_stone_defaults(),
})

-- Opal
minetest.register_craftitem("opal:opal", {
	description = ("Opal"),
	inventory_image = "opal_opal.png"
})
-- Ore
minetest.register_ore({
	ore_type       = "scatter",
	ore            = "opal:opal_ore",
	wherein        = "default:stone",
	clust_scarcity = 20 * 20 * 20,
	clust_num_ores = 4,
	clust_size     = 3,
	y_max          = -10,
	y_min          = -2000,
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "opal:opal_ore",
	wherein        = "default:stone",
	clust_scarcity = 15 * 15 * 15,
	clust_num_ores = 6,
	clust_size     = 5,
	y_max          = -50,
	y_min          = -10000,
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "opal:opal_ore",
	wherein        = "default:stone",
	clust_scarcity = 10 * 10 * 10,
	clust_num_ores = 8,
	clust_size     = 7,
	y_max          = -1000,
	y_min          = -20000,
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "opal:opal_ore",
	wherein        = "default:stone",
	clust_scarcity = 5 * 5 * 5,
	clust_num_ores = 10,
	clust_size     = 9,
	y_max          = -15000,
	y_min          = -31000,
})

-- Crafts
minetest.register_craft({
	output = "opal:opal_block",
	recipe = {
		{"opal:opal", "opal:opal", "opal:opal"},
		{"opal:opal", "opal:opal", "opal:opal"},
		{"opal:opal", "opal:opal", "opal:opal"}
	},
})

minetest.register_craft({
	output = "opal:opal 9",
	recipe = {
		{"opal:opal_block"}
	},
})

minetest.register_craft({
	output = "opal:opal_glass 4",
	recipe = {
		{"", "opal:opal", ""},
		{"opal:opal", "default:glass", "opal:opal"},
		{"", "opal:opal", ""}
	},
})

minetest.register_craft({
	output = "opal:opal_brick 4",
	recipe = {
		{"opal:opal_block", "opal:opal_block"},
		{"opal:opal_block", "opal:opal_block"},
	},
})

minetest.register_craft({
	output = "opal:opal_pillar 2",
	recipe = {
		{"opal:opal_block"},
		{"opal:opal_block"}
	},
})

minetest.register_craft({
	type = "cooking",
	output = "opal:opal_brick_cracked",
	recipe = "opal:opal_brick"
})

minetest.register_craft({
	type = "cooking",
	output = "opal:opal_pillar_cracked",
	recipe = "opal:opal_pillar"
})