-- Block and Ore
minetest.register_node("myrane:myrane_ore", {
	description = ("Myrane Ore"),
	tiles = {"default_stone.png^myrane_myrane_ore.png"},
	is_ground_content = true,
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "myrane:myrane_gem",
})

minetest.register_node("myrane:myrane_block", {
	description = ("Myrane Block"),
	tiles = {"myrane_myrane_block.png"},
	groups = {cracky = 1, level = 3},
	light_source = 50,
	sounds = default.node_sound_glass_defaults(),
})


-- Tools
minetest.register_tool("myrane:myrane_sword", {
	description = ("Myrane Sword"),
	inventory_image = "myrane_myrane_sword.png",
	tool_capabilties = {
		full_punch_interval = 0.5,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.4, [2]=0.3, [3]=0.2}, uses=400, maxlevel=3},
		},
		damage_groups = {fleshy=11},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {sword = 1},
})

minetest.register_tool("myrane:myrane_pickaxe", {
	description = ("Myrane Pickaxe"),
	inventory_image = "myrane_myrane_pickaxe.png",
	tool_capabilties = {
		full_punch_interval = 0.6,
		max_drop_level = 1,
		groupcaps = {
			cracky={times={[1]=0.4, [2]=0.3, [3]=0.2}, uses=400, maxlevel=3},
		},
		damage_groups = {fleshy=9},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1},
})

minetest.register_tool("myrane:myrane_axe", {
	description = ("Myrane Axe"),
	inventory_image = "myrane_myrane_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level = 1,
		groupcaps = {
			choppy={times={[1]=0.4, [2]=0.3, [3]=0.2}, uses=400, maxlevel=3},
		},
		damage_groups = {fleshy=10},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {axe = 1},
})

minetest.register_tool("myrane:myrane_shovel", {
	description = ("Myrane Shovel"),
	inventory_image = "myrane_myrane_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level = 1,
		groupcaps = {
			crumbly={times={[1]=0.4, [2]=0.3, [3]=0.2}, uses=400, maxlevel=3},
		},
		damage_groups = {fleshy=8},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {shovel = 1},
})

-- Ore
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "myrane:myrane_ore",
		wherein        = "default:stone",
		clust_scarcity = 20 * 20 * 20,
		clust_num_ores = 3,
		clust_size     = 2,
		y_max          = -250,
		y_min          = -10000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "myrane:myrane_ore",
		wherein        = "default:stone",
		clust_scarcity = 19 * 19 * 19,
		clust_num_ores = 4,
		clust_size     = 3,
		y_max          = -500,
		y_min          = -31000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "myrane:myrane_ore",
		wherein        = "default:stone",
		clust_scarcity = 17 * 17 * 17,
		clust_num_ores = 5,
		clust_size     = 4,
		y_max          = -750,
		y_min          = -31000,
	})

-- Gem
minetest.register_craftitem("myrane:myrane_gem", {
	description = ("Myrane Gem"),
	inventory_image = "myrane_myrane_gem.png",
})

-- Tool Crafts
minetest.register_craft({
	output = "myrane:myrane_sword",
	recipe = {
		{"myrane:myrane_gem"},
		{"myrane:myrane_gem"},
		{"group:stick"},
	},
})

minetest.register_craft({
	output = "myrane:myrane_pickaxe",
	recipe = {
		{"myrane:myrane_gem", "myrane:myrane_gem", "myrane:myrane_gem"},
		{"", "group:stick", ""},
		{"", "group:stick", ""},
	},
})


minetest.register_craft({
	output = "myrane:myrane_axe",
	recipe = {
		{"myrane:myrane_gem", "myrane:myrane_gem", ""},
		{"myrane:myrane_gem", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "myrane:myrane_shovel",
	recipe = {
		{"myrane:myrane_gem"},
		{"group:stick"},
		{"group:stick"},
	},
})

-- Block and Gem Crafts
minetest.register_craft({
	output = "myrane:myrane_block",
	recipe = {
		{"myrane:myrane_gem", "myrane:myrane_gem", "myrane:myrane_gem"},
		{"myrane:myrane_gem", "myrane:myrane_gem", "myrane:myrane_gem"},
		{"myrane:myrane_gem", "myrane:myrane_gem", "myrane:myrane_gem"},
	},
})

minetest.register_craft({
	output = "myrane:myrane_gem 9",
	recipe = {
		{"myrane:myrane_block"},
	},
})

-- Armor Crafts
minetest.register_craft({
	output = "myrane:myrane_helmet",
	recipe = {
		{"myrane:myrane_gem", "myrane:myrane_gem", "myrane:myrane_gem"},
		{"myrane:myrane_gem", "", "myrane:myrane_gem"},
	},
})

minetest.register_craft({
	output = "myrane:myrane_chestplate",
	recipe = {
		{"myrane:myrane_gem", "", "myrane:myrane_gem"},
		{"myrane:myrane_gem", "myrane:myrane_gem", "myrane:myrane_gem"},
		{"myrane:myrane_gem", "myrane:myrane_gem", "myrane:myrane_gem"},
	},
})

minetest.register_craft({
	output = "myrane:myrane_leggings",
	recipe = {
		{"myrane:myrane_gem", "myrane:myrane_gem", "myrane:myrane_gem"},
		{"myrane:myrane_gem", "", "myrane:myrane_gem"},
		{"myrane:myrane_gem", "", "myrane:myrane_gem"},
	},
})

minetest.register_craft({
	output = "myrane:myrane_boots",
	recipe = {
		{"myrane:myrane_gem", "", "myrane:myrane_gem"},
		{"myrane:myrane_gem", "", "myrane:myrane_gem"},
	},
})

minetest.register_craft({
	output = "myrane:myrane_shield",
	recipe = {
		{"myrane:myrane_gem", "myrane:myrane_gem", "myrane:myrane_gem"},
		{"myrane:myrane_gem", "myrane:myrane_gem", "myrane:myrane_gem"},
		{"", "myrane:myrane_gem", ""},
	},
})

-- Armor Registration
if minetest.get_modpath("3d_armor") then
	armor:register_armor("myrane:myrane_helmet", {
		description = ("Myrane Helmet"),
		inventory_image = "myrane_myrane_helmet_inv.png",
		groups = {armor_head=1, armor_heal=21, armor_use=150, armor_water=2, armor_feather=1},
		armor_groups = {fleshy=9},
		damage_groups = {cracky=4, snappy=2, level=15},
	})

	armor:register_armor("myrane:myrane_chestplate", {
		description = ("Myrane Chestplate"),
		inventory_image = "myrane_myrane_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=23, armor_use=150, armor_water=2, armor_feather=1},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=6, snappy=4, level=17},
	})

	armor:register_armor("myrane:myrane_leggings", {
		description = ("Myrane Leggings"),
		inventory_image = "myrane_myrane_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=22, armor_use=150, armor_water=2, armor_feather=1},
		armor_groups = {fleshy=10},
		damage_groups = {cracky=5, snappy=3, level=16},
	})

	armor:register_armor("myrane:myrane_boots", {
		description = ("Myrane Boots"),
		inventory_image = "myrane_myrane_boots_inv.png",
		groups = {armor_feet=1, armor_heal=20, armor_use=150, armor_water=2, physics_speed=1, armor_feather=1},
		armor_groups = {fleshy=8},
		damage_groups = {cracky=3, snappy=1, level=15},
	})

	armor:register_armor("myrane:myrane_shield", {
		description = ("Myrane Shield"),
		inventory_image = "myrane_myrane_shield_inv.png",
		groups = {armor_shield=1, armor_heal=24, armor_use=150, armor_water=2, armor_feather=1},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=5, snappy=4, level=17},
	})
end