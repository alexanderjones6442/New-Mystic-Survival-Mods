--Simplified rank checking and color handling.Corrected the rank checking logic to match exactly with the rank_colors keys.Improved the rankup logic to be --more maintainable by storing rank requirements in a table.Corrected and added error handling for potential issues.

local ranks = {}


local input, errstr = io.open(minetest.get_worldpath().."/ranks.dat", "r")
if input then
	ranks = minetest.deserialize(input:read("*a") or {})
	io.close(input)
else
	print("[rank] "..minetest.get_worldpath().."/ranks.dat failed to load! ("..errstr..")")
end

function color(hex)
	return core.get_color_escape_sequence(hex)
end

local rank_colors = {
	Wood = "#60311b",
	Stone = "#7f7f7f",
	Coal = "#2e2e2e",
	Aquamarine = "7fffd4",
	Iron = "#baada3",
	Copper = "#b64100",
	Bronze = "#cd7f32",
	Gold = "#ffd700",
	Mese = "#a6a600",
	Beryl = "#dde1b7",
	Corundrum = "4a6267",
	Diamond = "#0096ff",
	Amethyst = "9966cc",
	Obsidian = "#1a1a1a",
	Synlium = "#9a8f8f",
	Mithril = "#800080",
	Cerennium = "00099e",
	Crystal = "#add8e6",
	Lava = "#b5332e",
	Nether = "#a2b16d",
	Etherium = "#9a94f1",
	Aurenite = "#2d2a28",
	Ravinite = "#7d1201",
	Staff = "#410041",
	Helper = "#2859d6",
	Admin = "#ff0000",
	Moderator = "#0000ff",
	Co-Admin = "#ffa500",
}

minetest.register_privilege("rank", {description = "Can change ranks", give_to_singleplayer = false})

minetest.register_chatcommand("rank", {
	description = "Set a player's rank",
	params = "<name> <rank>",
	privs = {server = true, rank = true},
	func = function(name, param)
		local params = param:split(' ')
		local target = params[1]
		local new_rank = params[2]
		if not new_rank then
			return false, "Invalid Usage. See /help rank."
		end
		if rank_colors[new_rank] then
			if minetest.get_player_by_name(target) then
				minetest.get_player_by_name(target):set_nametag_attributes({text = "["..color(rank_colors[new_rank])..new_rank..color("#ffffff").."] "..target})
				ranks[target] = new_rank
				minetest.chat_send_player(name, target.."'s rank has been changed to "..new_rank..".")
			else
				minetest.chat_send_player(name, "Player not found.")
			end
		else
			minetest.chat_send_player(name, minetest.colorize("#FF0000", "Invalid Rank: "..new_rank))
		end
	end
})

minetest.register_on_joinplayer(function(player)
	minetest.after(0, function()
		local name = player:get_player_name()
		local player_rank = ranks[name]
		if player_rank then
			player:set_nametag_attributes({text = "["..color(rank_colors[player_rank])..player_rank..color("#ffffff").."] "..name})
		else
			ranks[name] = "Wood"
			player:set_nametag_attributes({text = "["..color(rank_colors["Wood"]).."Wood"..color("#ffffff").."] "..name})
		end
	end)
end)

minetest.register_on_shutdown(function()
	print("[rank] Shutting down. Saving ranks.")
	local stream, err = io.open(minetest.get_worldpath().."/ranks.dat", "w")
	if stream then
		stream:write(minetest.serialize(ranks))
		io.close(stream)
	else
		print("[rank] "..minetest.get_worldpath().."/ranks.dat failed to load! ("..err..")")
	end
end)

minetest.register_on_chat_message(function(name, message)
	if message:sub(1,1) == "/" then
		return false
	end
	local pname = name
	minetest.chat_send_all("<["..minetest.colorize(rank_colors[ranks[name]], ranks[name]).."] "..pname.."> "..message)
	return true
end)

minetest.register_chatcommand("rankup", {
	description = "Increase your rank.",
	privs = {interact = true},
	params = "",
	func = function(name, param)
		local rank = ranks[name] or "Wood"
		local player = minetest.get_player_by_name(name)
		local wielditem = player:get_wielded_item()
		if not wielditem then
			return false, "You are not holding an item."
		end

		local rankup_requirements = {
			Wood = {item = "default:stone", count = 40, next_rank = "Stone"},
			Stone = {item = "default:coalblock", count = 20, next_rank = "Coal"},
			Coal = {item = "aquamarine:aquamarine_block", count = 20, next_rank = "Aquamarine"},
			Aquamarine = {item = "default:steelblock", count = 20, next_rank = "Iron"},
			Iron = {item = "default:copperblock", count = 20, next_rank = "Copper"},
			Copper = {item = "default:bronzeblock", count = 20, next_rank = "Bronze"},
			Bronze = {item = "default:goldblock", count = 20, next_rank = "Gold"},
			Gold = {item = "default:mese", count = 20, next_rank = "Mese"},
			Mese = {item = "beryl:beryl_block", count = 20, next_rank = "Beryl"},
			Beryl = {item = "corundrum:corundrum_block", count = 20, next_rank = "Corundrum"},
			Corundrum = {item = "default:diamondblock", count = 20, next_rank = "Diamond"},
			Diamond = {item = "amethyst:amethyst_block", count = 20, next_rank = "Amethyst"},
			Amethyst = {item = "synlium:synlium_block", count = 20, next_rank = "Synlium"},
			Synlium = {item = "moreores:mithril_block", count = 20, next_rank = "Mithril"},
			Mithril = {item = "cerennium:cerennium_block", count = 15, next_rank = "Cerennium"},
			Cerennium = {item = "default:obsidian", count = 20, next_rank = "Obsidian"},
			Obsidian = {item = "lavastuff:block", count = 10, next_rank = "Lava"},
			Lava = {item = "ethereal:crystal_block", count = 15, next_rank = "Crystal"},
			Crystal = {item = "nether:nether_ingot", count = 50, next_rank = "Nether"},
			Nether = {item = "myrane:myrane_block", count = 20, next_rank = "Myrane"},
			Myrane = {item = "etherium:etherium_block", count = 15, next_rank = "Etherium"},
			Etherium = {item = "helixite:helixite_block", count = 15, next_rank = "Helixite"},
			Helixite = {item = "moissanite:moissanite_block", count = 15, next_rank = "Moissanite"},
			Moissanite = {item = "rubenite:rubenite_block", count = 15, next_rank = "Rubenite"},
			Rubenite = {item = "musgravite:musgravite_block", count = 12, next_rank = "Musgravite"},
			Musgravite = {item = "alexandrite:alexandrite_block", count = 12, next_rank = "Alexandrite"},
			Alexandrite = {item = "ardelion:ardelion_block", count = 10, next_rank = "Ardelion"},
			Ardelion = {item = "aurenite:aurenite_block", count = 10, next_rank = "Aurenite"},
			Aurenite = {item = "ravinite:ravinite_block", count = 5, next_rank = "Ravinite"}
		}

		local requirement = rankup_requirements[rank]
		if not requirement then
			minetest.chat_send_player(name, "You cannot rank up from your current rank.")
			return
		end

		if wielditem:get_count() >= requirement.count and wielditem:get_name() == requirement.item then
			wielditem:set_count(wielditem:get_count() - requirement.count)
			player:set_wielded_item(wielditem)
			ranks[name] = requirement.next_rank
			player:set_nametag_attributes({text = "["..color(rank_colors[requirement.next_rank])..requirement.next_rank..color("#ffffff").."] "..name})
			minetest.chat_send_all("Congratulations "..name.." for upgrading to the "..color(rank_colors[requirement.next_rank])..requirement.next_rank..color("#ffffff").." rank!")
		else
			minetest.chat_send_player(name, minetest.colorize("#ff0000", "ERROR: You need to hold "..requirement.count.." "..requirement.item.." to upgrade."))
		end
	end
})