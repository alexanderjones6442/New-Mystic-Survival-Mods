-----------------
-- Ores/Blocks --
-----------------
minetest.register_node("rubenite:rubenite_block", {
	description = ("Rubenite Block"),
	tiles = {"rubenite_rubenite_block.png"},
	is_ground_content = true,
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rubenite:rubenite_ore", {
	description = ("Rubenite Ore"),
	tiles = {"default_stone.png^rubenite_rubenite_ore.png"},
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "rubenite:rubenite_crystal",
})

-----------
-- Tools --
-----------
minetest.register_tool("rubenite:rubenite_sword", {
	description = ("Rubenite Sword"),
	inventory_image = "rubenite_rubenite_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.4,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.27, [2]=0.2, [3]=0.12}, uses=3000, maxlevel=3},
		},
		damage_groups = {fleshy=27},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("rubenite:rubenite_pickaxe", {
	description = ("Rubenite Pickaxe"),
	inventory_image = "rubenite_rubenite_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			cracky={times={[1]=0.27, [2]=0.2, [3]=0.12}, uses=3000, maxlevel=3},
		},
		damage_groups = {fleshy=25},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1}
})

minetest.register_tool("rubenite:rubenite_axe", {
	description = ("Rubenite Axe"),
	inventory_image = "rubenite_rubenite_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=0.27, [2]=0.2, [3]=0.12}, uses=3000, maxlevel=3},
		},
		damage_groups = {fleshy=26},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {axe = 1},
})

minetest.register_tool("rubenite:rubenite_shovel", {
	description = ("Rubenite Shovel"),
	inventory_image = "rubenite_rubenite_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level=1,
		groupcaps={
			crumbly={times={[1]=0.27, [2]=0.2, [3]=0.12}, uses = 3000, maxlevel=3},
		},
		damage_groups = {fleshy=24},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel = 1},
})

------------
-- Mapgen --
------------

-- Rubenite Ore

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "rubenite:rubenite_ore",
		wherein        = "default:stone",
		clust_scarcity = 32 * 32 * 32,
		clust_num_ores = 1,
		clust_size     = 1,
		y_max          = -10000,
		y_min          = -20000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "rubenite:rubenite_ore",
		wherein        = "default:stone",
		clust_scarcity = 30 * 30 * 30,
		clust_num_ores = 2,
		clust_size     = 1,
		y_max          = -15000,
		y_min          = -25000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "rubenite:rubenite_ore",
		wherein        = "default:stone",
		clust_scarcity = 28 * 28 * 28,
		clust_num_ores = 3,
		clust_size     = 2,
		y_max          = -15000,
		y_min          = -31000,
	})
-----------------
-- Craft Items --
-----------------
minetest.register_craftitem("rubenite:rubenite_crystal", {
	description = ("Rubenite Crystal"),
	inventory_image = "rubenite_rubenite_crystal.png"
})

------------
-- Crafts --
------------

-- Block
minetest.register_craft({
	output = "rubenite:rubenite_block",
	recipe = {
		{"rubenite:rubenite_crystal", "rubenite:rubenite_crystal", "rubenite:rubenite_crystal"},
		{"rubenite:rubenite_crystal", "rubenite:rubenite_crystal", "rubenite:rubenite_crystal"},
		{"rubenite:rubenite_crystal", "rubenite:rubenite_crystal", "rubenite:rubenite_crystal"},
	},
})

minetest.register_craft({
	output = "rubenite:rubenite_crystal 9",
	recipe = {
		{"rubenite:rubenite_block"},
	},
})

-- Tools

minetest.register_craft({
	output = "rubenite:rubenite_sword",
	recipe = {
		{"rubenite:rubenite_crystal"},
		{"rubenite:rubenite_crystal"},
		{"group:stick"},
	},
})

minetest.register_craft({
	output = "rubenite:rubenite_pickaxe",
	recipe = {
		{"rubenite:rubenite_crystal", "rubenite:rubenite_crystal", "rubenite:rubenite_crystal"},
		{"", "group:stick", ""},
		{"", "group:stick", ""},
	},
})

minetest.register_craft({
	output = "rubenite:rubenite_axe",
	recipe = {
		{"rubenite:rubenite_crystal", "rubenite:rubenite_crystal", ""},
		{"rubenite:rubenite_crystal", "group:stick", ""},
		{"", "group:stick", ""},
	},
})

minetest.register_craft({
	output = "rubenite:rubenite_shovel",
	recipe = {
		{"rubenite:rubenite_crystal"},
		{"default:steel_ingot"},
		{"default:steel_ingot"},
	},
})

-- Armor
minetest.register_craft({
	output = "rubenite:rubenite_helmet",
	recipe = {
		{"rubenite:rubenite_crystal", "rubenite:rubenite_crystal", "rubenite:rubenite_crystal"},
		{"rubenite:rubenite_crystal", "", "rubenite:rubenite_crystal"},
		{"", "", ""}
	},
})

minetest.register_craft({
	output = "rubenite:rubenite_chestplate",
	recipe = {
		{"rubenite:rubenite_crystal", "", "rubenite:rubenite_crystal"},
		{"rubenite:rubenite_crystal", "rubenite:rubenite_crystal", "rubenite:rubenite_crystal"},
		{"rubenite:rubenite_crystal", "rubenite:rubenite_crystal", "rubenite:rubenite_crystal"},
	},
})

minetest.register_craft({
	output = "rubenite:rubenite_leggings",
	recipe = {
		{"rubenite:rubenite_crystal", "rubenite:rubenite_crystal", "rubenite:rubenite_crystal"},
		{"rubenite:rubenite_crystal", "", "rubenite:rubenite_crystal"},
		{"rubenite:rubenite_crystal", "", "rubenite:rubenite_crystal"},
	},
})

minetest.register_craft({
	output = "rubenite:rubenite_boots",
	recipe = {
		{"rubenite:rubenite_crystal", "", "rubenite:rubenite_crystal"},
		{"rubenite:rubenite_crystal", "", "rubenite:rubenite_crystal"},
	},
})
----------------------
-- 3D Armor support --
----------------------
if minetest.get_modpath("3d_armor") then
	armor:register_armor("rubenite:rubenite_helmet", {
		description = ("Rubenite Helmet"),
		inventory_image = "rubenite_rubenite_helmet.png",
		groups = {armor_head=1, armor_heal=35, armor_use=120, armor_fire=1},
		armor_groups = {fleshy=10},
		damage_groups = {cracky=2, snappy=1, level=35},
	})

	armor:register_armor("rubenite:rubenite_chestplate", {
		description = ("Rubenite Chestplate"),
		inventory_image = "rubenite_rubenite_chestplate.png",
		groups = {armor_torso=1, armor_heal=37, armor_use=120, armor_fire=1},
		armor_groups = {fleshy=12},
		damage_groups = {cracky=2, snappy=1, level=37},
	})

	armor:register_armor("rubenite:rubenite_leggings", {
		description = ("Rubenite Leggings"),
		inventory_image = "rubenite_rubenite_leggings.png",
		groups = {armor_legs=1, armor_heal=36, armor_use=120, armor_fire=1},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=2, snappy=1, level=36},
	})

	armor:register_armor("rubenite:rubenite_boots", {
		description = ("Rubenite Boots"),
		inventory_image = "rubenite_rubenite_boots.png",
		groups = {armor_feet=1, armor_heal=34, armor_use=120, armor_fire=1, physics_speed=0.5},
		armor_groups = {fleshy=9},
		damage_groups = {cracky=2, snappy=1, level=34},
	})

end