-- Block and Ore
minetest.register_node("helixite:helixite_block", {
	description = ("Helixite Block"),
	tiles = {"helixite_helixite_block.png"},
	is_ground_content = false,
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_glass_defaults(),
})

minetest.register_node("helixite:helixite_ore", {
	description = ("Helixite Ore"),
	tiles = {"default_stone.png^helixite_helixite_ore.png"},
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "helixite:helixite_gem",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "helixite:helixite_ore",
	wherein        = "default:stone",
	clust_scarcity = 25 * 25 * 25,
	clust_num_ores = 4,
	clust_size     = 3,
	y_max          = -2000,
	y_min          = -20000,
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "helixite:helixite_ore",
	wherein        = "default:stone",
	clust_scarcity = 24 * 24 * 24,
	clust_num_ores = 5,
	clust_size     = 3,
	y_max          = -5000,
	y_min          = -28000,
})

-- Tools
minetest.register_tool("helixite:helixite_sword", {
	description = ("Helixite Sword"),
	inventory_image = "helixite_helixite_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.35, [2]=0.25, [3]=0.2}, uses=2750, maxlevel=3},
		},
		damage_groups = {fleshy=24},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1},
})

minetest.register_tool("helixite:helixite_pickaxe", {
	description = ("Helixite Pickaxe"),
	inventory_image = "helixite_helixite_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			cracky={times={[1]=0.35, [2]=0.25, [3]=0.2}, uses=2750, maxlevel=3},
		},
		damage_groups = {fleshy=22},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1},
})

minetest.register_tool("helixite:helixite_axe", {
	description = ("Helixite Axe"),
	inventory_image = "helixite_helixite_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			choppy={times={[1]=0.35, [2]=0.25, [3]=0.2}, uses=2750, maxlevel=3},
		},
		damage_groups = {fleshy=23},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {axe = 1},
})

minetest.register_tool("helixite:helixite_shovel", {
	description = ("Helixite Shovel"),
	inventory_image = "helixite_helixite_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level = 1,
		groupcaps = {
			crumbly={times={[1]=0.35, [2]=0.25, [3]=0.2}, uses=2750, maxlevel=3},
		},
		damage_groups = {fleshy=20},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel = 1},
})


-- Gem
minetest.register_craftitem("helixite:helixite_gem", {
	description = ("Helixite Gem"),
	inventory_image = "helixite_helixite_gem.png",
})

-- Crafts
minetest.register_craft({
	output = "helixite:helixite_block",
	recipe = {
		{"helixite:helixite_gem", "helixite:helixite_gem", "helixite:helixite_gem"},
		{"helixite:helixite_gem", "helixite:helixite_gem", "helixite:helixite_gem"},
		{"helixite:helixite_gem", "helixite:helixite_gem", "helixite:helixite_gem"}
	},
})

minetest.register_craft({
	output = "helixite:helixite_gem 9",
	recipe = {
		{"helixite:helixite_block"}
	},
})

minetest.register_craft({
	output = "helixite:helixite_sword",
	recipe = {
		{"helixite:helixite_gem"},
		{"helixite:helixite_gem"},
		{"group:stick"}
	},
})

minetest.register_craft({
	output = "helixite:helixite_pickaxe",
	recipe = {
		{"helixite:helixite_gem", "helixite:helixite_gem", "helixite:helixite_gem"},
		{"", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "helixite:helixite_axe",
	recipe = {
		{"helixite:helixite_gem", "helixite:helixite_gem", ""},
		{"helixite:helixite_gem", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "helixite:helixite_shovel",
	recipe = {
		{"helixite:helixite_gem"},
		{"group:stick"},
		{"group:stick"}
	},
})

minetest.register_craft({
	output = "helixite:helixite_helmet",
	recipe = {
		{"helixite:helixite_gem", "helixite:helixite_gem", "helixite:helixite_gem"},
		{"helixite:helixite_gem", "", "helixite:helixite_gem"}
	},
})

minetest.register_craft({
	output = "helixite:helixite_chestplate",
	recipe = {
		{"helixite:helixite_gem", "", "helixite:helixite_gem"},
		{"helixite:helixite_gem", "helixite:helixite_gem", "helixite:helixite_gem"},
		{"helixite:helixite_gem", "helixite:helixite_gem", "helixite:helixite_gem"}
	},
})

minetest.register_craft({
	output = "helixite:helixite_leggings",
	recipe = {
		{"helixite:helixite_gem", "helixite:helixite_gem", "helixite:helixite_gem"},
		{"helixite:helixite_gem", "", "helixite:helixite_gem"},
		{"helixite:helixite_gem", "", "helixite:helixite_gem"}
	},
})

minetest.register_craft({
	output = "helixite:helixite_boots",
	recipe = {
		{"helixite:helixite_gem", "", "helixite:helixite_gem"},
		{"helixite:helixite_gem", "", "helixite:helixite_gem"}
	},
})

minetest.register_craft({
	output = "helixite:helixite_shield",
	recipe = {
		{"helixite:helixite_gem", "helixite:helixite_gem", "helixite:helixite_gem"},
		{"helixite:helixite_gem", "helixite:helixite_gem", "helixite:helixite_gem"},
		{"", "helixite:helixite_gem", ""}
	},
})

-- Armor
if minetest.get_modpath("3d_armor") then
	armor:register_armor("helixite:helixite_helmet", {
		description = ("Helixite Helmet"),
		inventory_image = "helixite_helixite_helmet_inv.png",
		groups = {armor_head=1, armor_heal=32, armor_use=175, armor_fire=2},
		armor_groups = {fleshy=12},
		damage_groups = {cracky=2, choppy=1, level=33},
	})

	armor:register_armor("helixite:helixite_chestplate", {
		description = ("Helixite Chestplate"),
		inventory_image = "helixite_helixite_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=34, armor_use=175, armor_fire=2},
		armor_groups = {fleshy=14},
		damage_groups = {cracky=2, choppy=1, level=35},
	})

	armor:register_armor("helixite:helixite_leggings", {
		description = ("Helixite Leggings"),
		inventory_image = "helixite_helixite_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=33, armor_use=175, armor_fire=2},
		armor_groups = {fleshy=13},
		damage_groups = {cracky=2, choppy=1, level=34},
	})

	armor:register_armor("helixite:helixite_boots", {
		description = ("Helixite Boots"),
		inventory_image = "helixite_helixite_boots_inv.png",
		groups = {armor_feet=1, armor_heal=32, armor_use=175, armor_fire=2, physics_speed=1},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=2, choppy=1, level=33},
	})

	armor:register_armor("helixite:helixite_shield", {
		description = ("Helixite Shield"),
		inventory_image = "helixite_helixite_shield_inv.png",
		groups = {armor_shield=1, armor_heal=35, armor_use=175, armor_fire=2},
		armor_groups = {fleshy=15},
		damage_groups = {cracky=2, choppy=1, level=35},
	})

end