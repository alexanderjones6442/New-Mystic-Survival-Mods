--Block
minetest.register_node("aquamarine:aquamarine_block", {
	description = ("Aquamarine Block"),
	tiles = {"aquamarine_aquamarine_block.png"},
	is_ground_content = false,
	groups = {cracky=2, level=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("aquamarine:aquamarine_ore", {
	description = ("Aquamarine Ore"),
	tiles = {"default_stone.png^aquamarine_aquamarine_ore.png"},
	groups = {cracky=2, level=1},
	sounds = default.node_sound_stone_defaults(),
})

--Tools
minetest.register_tool("aquamarine:aquamarine_sword", {
	description = ("Aquamarine Sword"),
	inventory_image = "aquamarine_aquamarine_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.85,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=2.55, [2]=1.25, [3]=0.4}, uses=25, maxlevel=2},
		},
		damage_groups = {fleshy=6},
	},
	sounds = {breaks = default_tool_breaks},
	groups = {sword = 1}
})

minetest.register_tool("aquamarine:aquamarine_pickaxe", {
	description = ("Aquamarine Pickaxe"),
	inventory_image = "aquamarine_aquamarine_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 1,
		groupcaps = {
			cracky={times={[1]=2.55, [2]=1.25, [3]=0.4}, uses=25, maxlevel=2},
		},
		damage_groups = {fleshy=4},
	},
	sounds = {breaks = default_tool_breaks},
	groups = {pickaxe = 1}
})

minetest.register_node("aquamarine:aquamarine_axe", {
	description = ("Aquamarine Axe"),
	inventory_image = "aquamarine_aquamarine_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level = 1,
		groupcaps = {
			choppy={times={[1]=2.55, [2]=1.25, [3]=0.4}, uses=25, maxlevel=2},
		},
		damage_groups = {fleshy=5},
	},
	sounds = {breaks = default_tool_breaks},
	groups = {axe = 1},
})

minetest.register_node("aquamarine:aquamarine_shovel", {
	description = ("Aquamarine Shovel"),
	inventory_image = "aquamarine_aquamarine_shovel.png",
	tool_capabilities = {
		full_punch_interval = 1.05,
		max_drop_level = 1,
		groupcaps = {
			crumbly={times={[1]=2.55, [2]=1.25, [3]=0.4}, uses=25, maxlevel=2},
		},
		damage_groups = {fleshy=3},
	},
	sounds = {breaks = default_tool_breaks},
	groups = {shovel = 1}
})

-- Mapgen
minetest.register_ore({
	ore_type       = "scatter",
	ore            = "aquamarine:aquamarine_ore",
	wherein        = "default:stone",
	clust_scarcity = 12 * 12 * 12,
	clust_num_ores = 2,
	clust_size     = 3,
	y_max          = -100,
	y_min          = -10000,
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "aquamarine:aquamarine_ore",
	wherein        = "default:stone",
	clust_scarcity = 10 * 10 * 10,
	clust_num_ores = 3,
	clust_size     = 4,
	y_max          = -1000,
	y_min          = -20000,
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "aquamarine:aquamarine_ore",
	wherein        = "default:stone",
	clust_scarcity = 8 * 8 * 8,
	clust_num_ores = 4,
	clust_size     = 5,
	y_max          = -15000,
	y_min          = -31000,
})

-- Aquamarine
minetest.register_craftitem("aquamarine:aquamarine", {
	description = ("Aquamarine"),
	inventory_image = "aquamarine_aquamarine.png"
})

-- Crafts
minetest.register_craft({
	output = "aquamarine:aquamarine_sword",
	recipe = {
		{"aquamarine:aquamarine"},
		{"aquamarine:aquamarine"},
		{"group:stick"}
	},
})

minetest.register_craft({
	output = "aquamarine:aquamarine_pickaxe",
	recipe = {
		{"aquamarine:aquamarine", "aquamarine:aquamarine", "aquamarine:aquamarine"},
		{"", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "aquamarine:aquamarine_axe",
	recipe = {
		{"aquamarine:aquamarine", "aquamarine:aquamarine", ""},
		{"aquamarine:aquamarine", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "aquamarine:aquamarine_shovel",
	recipe = {
		{"aquamarine:aquamarine"},
		{"group:stick"},
		{"group:stick"}
	},
})

minetest.register_craft({
	output = "aquamarine:aquamarine_block",
	recipe = {
		{"aquamarine:aquamarine", "aquamarine:aquamarine", "aquamarine:aquamarine"},
		{"aquamarine:aquamarine", "aquamarine:aquamarine", "aquamarine:aquamarine"},
		{"aquamarine:aquamarine", "aquamarine:aquamarine", "aquamarine:aquamarine"}
	},
})

minetest.register_craft({
	output = "aquamarine:aquamarine 9",
	recipe = {
		{"aquamarine:aquamarine_block"}
	},
})

minetest.register_craft({
	output = "aquamarine:aquamarine_helmet",
	recipe = {
		{"aquamarine:aquamarine", "aquamarine:aquamarine", "aquamarine:aquamarine"},
		{"aquamarine:aquamarine", "", "aquamarine:aquamarine"}
	},
})

minetest.register_craft({
	output = "aquamarine:aquamarine_chestplate",
	recipe = {
		{"aquamarine:aquamarine", "", "aquamarine:aquamarine"},
		{"aquamarine:aquarmarine", "aquamarine:aquamarine", "aquamarine:aquamarine"},
		{"aquamarine:aquamarine", "aquamarine:aquamarine", "aquamarine:aquamarine"}
	},
})

minetest.register_craft({
	output = "aquamarine:aquamarine_leggings",
	recipe = {
		{"aquamarine:aquamarine", "aquamarine:aquamarine", "aquamarine:aquamarine"},
		{"aquamarine:aquamarine", "", "aquamarine:aquamarine"},
		{"aquamarine:aquamarine", "", "aquamarine:aquamarine"}
	},
})

minetest.register_craft({
	output = "aquamarine:aquamarine_boots",
	recipe = {
		{"aquamarine:aquamarine", "", "aquamarine:aquamarine"},
		{"aquamarine:aquamarine", "", "aquamarine:aquamarine"},
	},
})

minetest.register_craft({
	output = "aquamarine:aquamarine_shield",
	recipe = {
		{"aquamarine:aquamarine", "aquamarine:aquamarine", "aquamarine:aquamarine"},
		{"aquamarine:aquamarine", "aquamarine:aquamarine", "aquamarine:aquamarine"},
		{"", "aquamarine:aquamarine", "aquamarine:aquamarine"}
	},
})

-- Armor
if minetest.get_modpath("3d_armor") then
	armor:register_armor("aquamarine:aquamarine_helmet", {
		description = ("Aquamarine Helmet"),
		inventory_image = "aquamarine_aquamarine_helmet_inv.png",
		groups = {armor_head=1, armor_heal=6, armor_use=950},
		armor_groups = {fleshy=3},
		damage_groups = {cracky=2, choppy=1, level=6},
	})

	armor:register_armor("aquamarine:aquamarine_chestplate", {
		description = ("Aquamarine Chestplate"),
		inventory_image = "aquamarine_aquamarine_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=8, armor_use=950},
		armor_groups = {fleshy=4},
		damage_groups = {cracky=2, choppy=1, level=8},
	})

	armor:register_armor("aquamarine:aquamarine_leggings", {
		description = ("Aquamarine Leggings"),
		inventory_image = "aquamarine_aquamarine_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=7, armor_use=950},
		armor_groups = {fleshy=3.5},
		damage_groups = {cracky=2, choppy=1, level=7},
	})

	armor:register_armor("aquamarine:aquamarine_boots", {
		description = ("Aquamarine Boots"),
		inventory_image = "aquamarine_aquamarine_boots_inv.png",
		groups = {armor_feet=1, armor_heal=5, armor_use=950},
		armor_groups = {fleshy=2.5},
		damage_groups = {cracky=2, choppy=1, level=5},
	})

	armor:register_armor("aquamarine:aquamarine_shield", {
		description = ("Aquamarine Shield"),
		inventory_image = "aquamarine_aquamarine_shield_inv.png",
		groups = {armor_shield=1, armor_heal=8, armor_use=950},
		armor_groups = {fleshy=4},
		damage_groups = {cracky=2, choppy=1, level=8},
	})
end