-- Block and Ore
minetest.register_node("cerennium:cerennium_block", {
	description = ("Cerennium Block"),
	tiles = {"cerennium_cerennium_block.png"},
	is_ground_content = true,
	groups = {cracky=1, level=2},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("cerennium:cerennium_ore", {
	description = ("Cerennium Ore"),
	tiles = {"default_stone.png^cerennium_cerennium_ore.png"},
	is_ground_content = true,
	groups = {cracky=1, level=2},
	sounds = default.node_sound_stone_defaults(),
	drop = "cerennium:cerennium_shard"
})

-- Tools
minetest.register_tool("cerennium:cerennium_sword", {
	description = ("Cerennium Sword"),
	inventory_image = "cerennium_cerennium_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.45,
		max_drop_level=1,
		groupcaps = {
			snappy={times={[1]=0.7, [2]=0.5, [3]=0.2}, uses=400, maxlevel=3},
		},
		damage_groups = {fleshy=10},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1},
})

minetest.register_tool("cerennium:cerennium_pickaxe", {
	description = ("Cerennium Pickaxe"),
	inventory_image = "cerennium_cerennium_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.45,
		max_drop_level=1,
		groupcaps = {
			cracky={times={[1]=0.7, [2]=0.5, [3]=0.2}, uses=400, maxlevel=3},
		},
		damage_groups = {fleshy=8},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1},
})

minetest.register_tool("cerennium:cerennium_axe", {
	description = ("Cerennium Axe"),
	inventory_image = "cerennium_cerennium_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.45,
		max_drop_level=1,
		groupcaps = {
			choppy={times={[1]=0.7, [2]=0.5, [3]=0.2}, uses=400, maxlevel=3},
		},
		damage_groups = {fleshy=9},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {axe = 1},
})

minetest.register_tool("cerennium:cerennium_shovel", {
	description = ("Cerennium Shovel"),
	inventory_image = "cerennium_cerennium_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.45,
		max_drop_level=1,
		groupcaps = {
			crumbly={times={[1]=0.7, [2]=0.5, [3]=0.2}, uses=400, maxlevel=3},
		},
		damage_groups = {fleshy=7},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel = 1},
})

-- Ore Mapgen
minetest.register_ore({
	ore_type       = "scatter",
	ore            = "cerennium:cerennium_ore",
	wherein        = "default:stone",
	clust_scarcity = 20 * 20 * 20,
	clust_num_ores = 2,
	clust_size     = 3,
	y_max          = -500,
	y_min          = -15000,
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "cerennium:cerennium_ore",
	wherein        = "default:stone",
	clust_scarcity = 20 * 20 * 20,
	clust_num_ores = 3,
	clust_size     = 4,
	y_max          = -1000,
	y_min          = -25000,
})

-- Lump and Ingot
minetest.register_craftitem("cerennium:cerennium_shard", {
	description = ("Cerennium Shard"),
	inventory_image = "cerennium_cerennium_shard.png"
})

-- Armor/Tool/Block Crafts
minetest.register_craft({
	output = "cerennium:cerennnium_block",
	recipe = {
		{"cerennium:cerennium_shard", "cerennium:cerennium_shard", "cerennium:cerennium_shard"},
		{"cerennium:cerennium_shard", "cerennium:cerennium_shard", "cerennium:cerennium_shard"},
		{"cerennium:cerennium_shard", "cerennium:cerennium_shard", "cerennium:cerennium_shard"}
	},
})

minetest.register_craft({
	output = "cerennium:cerennium_shard 9",
	recipe = {
		{"cerennium:cerennium_block"}
	},
})

minetest.register_craft({
	output = "cerennium:cerennium_sword",
	recipe = {
		{"cerennium:cerennium_shard"},
		{"cerennium:cerennium_shard"},
		{"group:stick"},
	},
})

minetest.register_craft({
	output = "cerennium:cerennium_pickaxe",
	recipe = {
		{"cerennium:cerennium_shard", "cerennium:cerennium_shard", "cerennium:cerennium_shard"},
		{"", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "cerennium:cerennium_axe",
	recipe = {
		{"cerennium:cerennium_ingot", "cerennium:cerennium_ingot", ""},
		{"cerennium:cerennium_ingot", "group:stick", ""},
		{"", "group:stick", ""},
	},
})

minetest.register_craft({
	output = "cerennium:cerennium_shovel",
	recipe = {
		{"cerennium:cerennium_ingot"},
		{"group:stick"},
		{"group:stick"},
	},
})

minetest.register_craft({
	output = "cerennium:cerennium_helmet",
	recipe = {
		{"cerennium:cerennium_ingot", "cerennium:cerennium_ingot", "cerennium:cerennium_ingot"},
		{"cerennium:cerennium_ingot", "", "cerennium:cerennium_ingot"}
	},
})

minetest.register_craft({
	output = "cerennium:cerennium_chestplate",
	recipe = {
		{"cerennium:cerennium_ingot", "", "cerennium:cerennium_ingot"},
		{"cerennium:cerennium_ingot", "cerennium:cerennium_ingot", "cerennium:cerennium_ingot"},
		{"cerennium:cerennium_ingot", "cerennium:cerennium_ingot", "cerennium:cerennium_ingot"}
	},
})

minetest.register_craft({
	output = "cerennium:cerennium_leggings",
	recipe = {
		{"cerennium:cerennium_ingot", "cerennium:cerennium_ingot", "cerennium:cerennium_ingot"},
		{"cerennium:cerennium_ingot", "", "cerennium:cerennium_ingot"},
		{"cerennium:cerennium_ingot", "", "cerennium:cerennium_ingot"}
	},
})

minetest.register_craft({
	output = "cerennium:cerennium_boots",
	recipe = {
		{"cerennium:cerennium_ingot", "", "cerennium:cerennium_ingot"},
		{"cerennium:cerennium_ingot", "", "cerennium:cerennium_ingot"}
	},
})

minetest.register_craft({
	output = "cerennium:cerennium_shield",
	recipe = {
		{"cerennium:cerennium_ingot", "cerennium:cerennium_ingot", "cerennium:cerennium_ingot"},
		{"cerennium:cerennium_ingot", "cerennium:cerennium_ingot", "cerennium:cerennium_ingot"},
		{"", "cerennium:cerennium_ingot", ""}
	},
})

-- Armor
if minetest.get_modpath("3d_armor") then
	armor:register_armor("cerennium:cerennium_helmet", {
		description = ("Cerennium Helmet"),
		inventory_image = "cerennium_cerennium_helmet_inv.png",
		groups = {armor_head=1, armor_heal=16, armor_use=200, physics_jump=0.2},
		armor_groups = {fleshy=10},
		damage_groups = {cracky=2, choppy=1, level=20},
	})

	armor:register_armor("cerennium:cerennium_chestplate", {
		description = ("Cerennium Chestplate"),
		inventory_image = "cerennium_cerennium_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=18, armor_use=200, physics_jump=0.2},
		armor_groups = {fleshy=12},
		damage_groups = {cracky=2, choppy=1, level=22},
	})

	armor:register_armor("cerennium:cerennium_leggings", {
		description = ("Cerennium Leggings"),
		inventory_image = "cerennium_cerennium_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=17, armor_use=200, physics_jump=0.2},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=2, choppy=1, level=21},
	})

	armor:register_armor("cerennium:cerennium_boots", {
		description = ("Cerennium Boots"),
		inventory_image = "cerennium_cerennium_boots_inv.png",
		groups = {armor_feet=1, armor_heal=15, armor_use=200, physics_jump=0.2, physics_speed=0.3},
		armor_groups = {fleshy=9},
		damage_groups = {cracky=2, choppy=1, level=19},
	})

	armor:register_armor("cerennium:cerennium_shield", {
		description = ("Cerennium Shield"),
		inventory_image = "cerennium_cerennium_shield_inv.png",
		groups = {armor_shield=1, armor_heal=18, armor_use=200, physics_jump=0.2},
		armor_groups = {fleshy=12},
		damage_groups = {cracky=2, choppy=1, level=22},
	})
end