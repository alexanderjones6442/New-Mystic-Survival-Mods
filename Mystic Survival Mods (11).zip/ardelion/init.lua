-----------------
-- Ores/Blocks --
-----------------
minetest.register_node("ardelion:ardelion_block", {
	description = ("Ardelion Block"),
	tiles = {"ardelion_ardelion_block.png"},
	is_ground_content = true,
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("ardelion:ardelion_ore", {
	description = ("Ardelion Ore"),
	tiles = {"default_stone.png^ardelion_ardelion_ore.png"},
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "ardelion:ardelion_crystal",
})

-----------
-- Tools --
-----------
minetest.register_tool("ardelion:ardelion_sword", {
	description = ("Ardelion Sword"),
	inventory_image = "ardelion_ardelion_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.4,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.2, [2]=0.175, [3]=0.15}, uses=4500, maxlevel=3},
		},
		damage_groups = {fleshy=65},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("ardelion:ardelion_pickaxe", {
	description = ("Ardelion Pickaxe"),
	inventory_image = "ardelion_ardelion_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			cracky={times={[1]=0.2, [2]=0.175, [3]=0.15}, uses=4500, maxlevel=3},
		},
		damage_groups = {fleshy=59},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1}
})

minetest.register_tool("ardelion:ardelion_axe", {
	description = ("Ardelion Axe"),
	inventory_image = "ardelion_ardelion_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.45,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=0.2, [2]=0.175, [3]=0.15}, uses=4500, maxlevel=3},
		},
		damage_groups = {fleshy=63},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {axe = 1},
})

minetest.register_tool("ardelion:ardelion_shovel", {
	description = ("Ardelion Shovel"),
	inventory_image = "ardelion_ardelion_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.55,
		max_drop_level=1,
		groupcaps={
			crumbly={times={[1]=0.2, [2]=0.175, [3]=0.15}, uses = 4500, maxlevel=3},
		},
		damage_groups = {fleshy=55},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel = 1},
})

------------
-- Mapgen --
------------

-- Aurenite Ore

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "ardelion:ardelion_ore",
		wherein        = "default:stone",
		clust_scarcity = 70 * 70 * 70,
		clust_num_ores = 1,
		clust_size     = 1,
		y_max          = -9000,
		y_min          = -20000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "ardelion:ardelion_ore",
		wherein        = "default:stone",
		clust_scarcity = 60 * 60 * 60,
		clust_num_ores = 2,
		clust_size     = 1,
		y_max          = -10000,
		y_min          = -25000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "ardelion:ardelion_ore",
		wherein        = "default:stone",
		clust_scarcity = 50 * 50 * 50,
		clust_num_ores = 2,
		clust_size     = 2,
		y_max          = -20000,
		y_min          = -28000,
	})
-----------------
-- Craft Items --
-----------------
minetest.register_craftitem("ardelion:ardelion_crystal", {
	description = ("Ardelion Crystal"),
	inventory_image = "ardelion_ardelion_crystal.png"
})

------------
-- Crafts --
------------

-- Block
minetest.register_craft({
	output = "ardelion:ardelion_block",
	recipe = {
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", "ardelion:ardelion_crystal"},
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", "ardelion:ardelion_crystal"},
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", "ardelion:ardelion_crystal"},
	},
})

minetest.register_craft({
	output = "ardelion:ardelion_crystal 9",
	recipe = {
		{"ardelion:ardelion_block"},
	},
})

-- Tools

minetest.register_craft({
	output = "ardelion:ardelion_sword",
	recipe = {
		{"ardelion:ardelion_crystal"},
		{"ardelion:ardelion_crystal"},
		{"default:obsidian_shard"},
	},
})

minetest.register_craft({
	output = "ardelion:ardelion_pickaxe",
	recipe = {
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", "ardelion:ardelion_crystal"},
		{"", "", ""},
		{"", "default:obsidian_shard", ""},
	},
})

minetest.register_craft({
	output = "ardelion:ardelion_axe",
	recipe = {
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", ""},
		{"ardelion:ardelion_crystal", "default:obsidian_shard", ""},
		{"", "default:obsidian_shard", ""},
	},
})

minetest.register_craft({
	output = "ardelion:ardelion_shovel",
	recipe = {
		{"ardelion:ardelion_crystal"},
		{"default:obsidian_shard"},
		{"default:obsidian_shard"},
	},
})

-- Armor
minetest.register_craft({
	output = "ardelion:ardelion_helmet",
	recipe = {
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", "ardelion:ardelion_crystal"},
		{"ardelion:ardelion_crystal", "", "ardelion:ardelion_crystal"}
	},
})

minetest.register_craft({
	output = "ardelion:ardelion_chestplate",
	recipe = {
		{"ardelion:ardelion_crystal", "", "ardelion:ardelion_crystal"},
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", "ardelion:ardelion_crystal"},
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", "ardelion:ardelion_crystal"},
	},
})

minetest.register_craft({
	output = "ardelion:ardelion_leggings",
	recipe = {
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", "ardelion:ardelion_crystal"},
		{"ardelion:ardelion_crystal", "", "ardelion:ardelion_crystal"},
		{"ardelion:ardelion_crystal", "", "ardelion:ardelion_crystal"},
	},
})

minetest.register_craft({
	output = "ardelion:ardelion_boots",
	recipe = {
		{"ardelion:ardelion_crystal", "", "ardelion:ardelion_crystal"},
		{"ardelion:ardelion_crystal", "", "ardelion:ardelion_crystal"}
	},
})

minetest.register_craft({
	output = "ardelion:ardelion_shield",
	recipe = {
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", "ardelion:ardelion_crystal"},
		{"ardelion:ardelion_crystal", "ardelion:ardelion_crystal", "ardelion:ardelion_crystal"},
		{"", "ardelion:ardelion_crystal", ""}
	},
})
----------------------
-- 3D Armor support --
----------------------
if minetest.get_modpath("3d_armor") then
	armor:register_armor("ardelion:ardelion_helmet", {
		description = ("Ardelion Helmet"),
		inventory_image = "ardelion_ardelion_helmet_inv.png",
		groups = {armor_head=1, armor_heal=90, armor_use=25, armor_fire=3, physics_jump=0.25},
		armor_groups = {fleshy=20},
		damage_groups = {cracky=2, snappy=1, level=85},
	})

	armor:register_armor("ardelion:ardelion_chestplate", {
		description = ("Ardelion Chestplate"),
		inventory_image = "ardelion_ardelion_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=110, armor_use=25, armor_fire=3, physics_jump=0.25},
		armor_groups = {fleshy=22},
		damage_groups = {cracky=2, snappy=1, level=95},
	})

	armor:register_armor("ardelion:ardelion_leggings", {
		description = ("Ardelion Leggings"),
		inventory_image = "ardelion_ardelion_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=100, armor_use=25, armor_fire=3, physics_jump=0.25},
		armor_groups = {fleshy=21},
		damage_groups = {cracky=2, snappy=1, level=90},
	})

	armor:register_armor("ardelion:ardelion_boots", {
		description = ("Ardelion Boots"),
		inventory_image = "ardelion_ardelion_boots_inv.png",
		groups = {armor_feet=1, armor_heal=80, armor_use=25, armor_fire=3, physics_speed=1.5, physics_jump=0.25},
		armor_groups = {fleshy=19},
		damage_groups = {cracky=2, snappy=1, level=80},
	})

	armor:register_armor("ardelion:ardelion_shield", {
		description = ("Ardelion Shield"),
		inventory_image = "ardelion_ardelion_shield_inv.png",
		groups = {armor_shield=1, armor_heal=110, armor_use=25, armor_fire=3},
		armor_groups = {fleshy=22},
		damage_groups = {cracky=2, snappy=1, level=95},
	})
end