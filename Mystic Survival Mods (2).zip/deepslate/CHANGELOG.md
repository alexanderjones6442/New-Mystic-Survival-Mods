Deepslate Changelog
===================

0.2.0 (2023-03-13)
------------------

- Added a build script.
- Added documentation.
- Rearranged the source code.
- Added freejusticehere to the credits for Pixel Perfection Legacy.
- Added Rocks support.
- Added Silver support.
- Added Zinc support.
- Added Magic Materials support.
- Lightened Deepslate Tiles and Cracked Deepslate Tiles to make them more consistent with the other textures.


0.1.0 (2022-12-02)
------------------

- Added Repixture support.
- Added Ethereal support.
- Added More Blocks support.
- Improved MineClone support.
- Deepslate ores now inherit smelting recipes from the original ore.
- Fixed the internal name of Deepslate Glow Ore.


0.0.1 (2022-11-27)
------------------

- Deepslate slabs and stairs can no longer be used as stone in crafting recipes.
- Updated supported Minetest versions in metadata.


0.0.0 (2022-11-26)
------------------

- Added everything.
