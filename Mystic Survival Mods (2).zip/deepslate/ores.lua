--[[
    Deepslate — adds deepslate and related building materials to Minetest
    Copyright © 2022‒2023, Silver Sandstone <@SilverSandstone@craftodon.social>

    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the "Software"),
    to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense,
    and/or sell copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.
]]


-- Minetest Game:
deepslate.register_ore('deepslate:deepslate_with_coal',         'default:stone_with_coal', {ore_texture = 'default_mineral_coal.png^[multiply:#BFBFBF'});
deepslate.register_ore('deepslate:deepslate_with_copper',       'default:stone_with_copper');
deepslate.register_ore('deepslate:deepslate_with_tin',          'default:stone_with_tin');
deepslate.register_ore('deepslate:deepslate_with_iron',         'default:stone_with_iron');
deepslate.register_ore('deepslate:deepslate_with_diamond',      'default:stone_with_diamond');
deepslate.register_ore('deepslate:deepslate_with_gold',         'default:stone_with_gold');
deepslate.register_ore('deepslate:deepslate_with_mese',         'default:stone_with_mese');

-- More Ores:
deepslate.register_ore('deepslate:deepslate_with_mithril',      'moreores:mineral_mithril');
deepslate.register_ore('deepslate:deepslate_with_silver',       'moreores:mineral_silver');

-- Technic:
deepslate.register_ore('deepslate:deepslate_with_chromium',     'technic:mineral_chromium');
deepslate.register_ore('deepslate:deepslate_with_lead',         'technic:mineral_lead');
deepslate.register_ore('deepslate:deepslate_with_sulfur',       'technic:mineral_sulfur');
deepslate.register_ore('deepslate:deepslate_with_uranium',      'technic:mineral_uranium');
deepslate.register_ore('deepslate:deepslate_with_zinc',         'technic:mineral_zinc');

-- Glooptest:
deepslate.register_ore('deepslate:deepslate_with_alatro',       'glooptest:mineral_alatro');
deepslate.register_ore('deepslate:deepslate_with_arol',         'glooptest:mineral_arol');
deepslate.register_ore('deepslate:deepslate_with_amethyst',     'glooptest:mineral_amethyst');
deepslate.register_ore('deepslate:deepslate_with_emerald',      'glooptest:mineral_emerald');
deepslate.register_ore('deepslate:deepslate_with_kalite',       'glooptest:mineral_kalite');
deepslate.register_ore('deepslate:deepslate_with_ruby',         'glooptest:mineral_ruby');
deepslate.register_ore('deepslate:deepslate_with_sapphire',     'glooptest:mineral_sapphire');
deepslate.register_ore('deepslate:deepslate_with_talinite',     'glooptest:mineral_talinite');
deepslate.register_ore('deepslate:deepslate_with_topaz',        'glooptest:mineral_topaz');

-- Repixture:
deepslate.register_ore('deepslate:deepslate_with_coal',         'rp_default:stone_with_coal');
deepslate.register_ore('deepslate:deepslate_with_graphite',     'rp_default:stone_with_graphite');
deepslate.register_ore('deepslate:deepslate_with_tin',          'rp_default:stone_with_tin');
deepslate.register_ore('deepslate:deepslate_with_copper',       'rp_default:stone_with_copper');
deepslate.register_ore('deepslate:deepslate_with_iron',         'rp_default:stone_with_iron');
deepslate.register_ore('deepslate:deepslate_with_sulfur',       'rp_default:stone_with_sulfur');
deepslate.register_ore('deepslate:deepslate_with_gold',         'rp_gold:stone_with_gold');
deepslate.register_ore('deepslate:deepslate_with_lumien',       'rp_lumien:stone_with_lumien');

-- Techage:
deepslate.register_ore('deepslate:deepslate_with_baborium',     'techage:stone_with_baborium');

-- Blox:
deepslate.register_ore('deepslate:deepslate_with_glow_ore',     'blox:glowore');

-- Quartz:
deepslate.register_ore('deepslate:deepslate_with_quartz',       'quartz:quartz_ore');

-- Lapis Lazuli:
deepslate.register_ore('deepslate:deepslate_with_lapis',        'lapis:stone_with_lapis');

-- Rainbow Ore:
deepslate.register_ore('deepslate:deepslate_with_rainbow_ore',  'rainbow_ore:rainbow_ore_block',
{
    ore_texture = 'raibow_ore.png'; -- The spelling mistake is from the Rainbow Ore mod.
});

-- Legendary Ore:
deepslate.register_ore('deepslate:deepslate_with_legendary_ore', 'legendary_ore:legendary_ore',
{
    ore_texture = 'legendary_ore_ore.png';
});

-- Titanium:
deepslate.register_ore('deepslate:deepslate_with_titanium',     'titanium:titanium_in_ground');

-- Ethereal:
deepslate.register_ore('deepslate:deepslate_with_etherium_ore', 'ethereal:stone_with_etherium_ore');

-- Silver:
deepslate.register_ore('deepslate:deepslate_with_silver',       'silver:silver_ore');

-- Zinc:
deepslate.register_ore('deepslate:deepslate_with_zinc',         'zinc:stone_with_zinc');

-- Magic Materials:
deepslate.register_ore('deepslate:deepslate_with_egerum',       'magic_materials:stone_with_egerum');
deepslate.register_ore('deepslate:deepslate_with_februm',       'magic_materials:stone_with_februm');

-- Aurenite:
deepslate.register_ore('deepslate:deepslate_with_aurenite',       'aurenite:aurenite_ore');
