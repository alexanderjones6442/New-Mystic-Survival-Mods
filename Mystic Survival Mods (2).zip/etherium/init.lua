-- Blocks
minetest.register_node("etherium:etherium_block", {
	description = ("Etherium Block"),
	tiles = {"etherium_etherium_block.png"},
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
})

-- Tools
minetest.register_tool("etherium:etherium_sword", {
	description = ("Etherium Sword"),
	inventory_image = "etherium_etherium_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.4,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses = 400, maxlevel = 3},
		},
		damage_groups = {fleshy=12},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("etherium:etherium_pickaxe", {
	description = ("Etherium Pickaxe"),
	inventory_image = "etherium_etherium_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level = 1,
		groupcaps = {
			cracky={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses = 400, maxlevel = 3},
		},
		damage_groups = {fleshy=9},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1}
})

minetest.register_tool("etherium:etherium_axe", {
	description = ("Etherium Axe"),
	inventory_image = "etherium_etherium_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level = 1,
		groupcaps = {
			choppy={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses = 400, maxlevel = 3},
		},
		damage_groups = {fleshy=10},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {axe = 1}
})

minetest.register_tool("etherium:etherium_shovel", {
	description = ("Etherium Shovel"),
	inventory_image = "etherium_etherium_shovel.png",
	tool_capabilties = {
		full_punch_interval = 0.7,
		max_drop_level = 1,
		groupcaps = {
			crumbly={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses = 400, maxlevel = 3},
		},
		damage_groups = {fleshy=8},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {shovel = 1},
})

if minetest.get_modpath("multitools") then
	minetest.register_tool("etherium:etherium_multitool", {
		description = ("Etherium Multitool"),
		inventory_image = "etherium_etherium_multitool.png",
		tool_capabilties = {
			full_punch_interval = 0.5,
			max_drop_level = 1,
			groupcaps = {
				snappy={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses=400, maxlevel=3},
				cracky={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses=400, maxlevel=3},
				choppy={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses=400, maxlevel=3},
				crumbly={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses=400, maxlevel=3},
			},
			damage_groups = {fleshy = 12},
		},
		sounds = {breaks = "default_tool_breaks"},
		groups = {sword = 1, pickaxe = 1, axe = 1, shovel = 1},
	})
end

-- Lump and Ingot
minetest.register_craftitem("etherium:etherium_lump", {
	description = ("Etherium Lump"),
	inventory_image = "etherium_etherium_lump.png"
})

minetest.register_craftitem("etherium:etherium_ingot", {
	description = ("Etherium Ingot"),
	inventory_image = "etherium_etherium_ingot.png"
})

-- Crafts --
-- Lump
minetest.register_craft({
	output = "etherium:etherium_lump",
	recipe = {
		{"ethereal:etherium_dust", "moreores:silver_lump"},
	},
})

-- Smelting Recipe
minetest.register_craft({
	type = "cooking",
	output = "etherium:etherium_ingot",
	recipe = "etherium:etherium_lump",
	cooktime = 3
})

--Block
minetest.register_craft({
	output = "etherium:etherium_block",
	recipe = {
		{"etherium:etherium_ingot", "etherium:etherium_ingot", "etherium:etherium_ingot"},
		{"etherium:etherium_ingot", "etherium:etherium_ingot", "etherium:etherium_ingot"},
		{"etherium:etherium_ingot", "etherium:etherium_ingot", "etherium:etherium_ingot"}
	},
})

minetest.register_craft({
	output = "etherium:etherium_ingot 9",
	recipe = {
		{"etherium:etherium_block"}
	},
})

-- Tools
minetest.register_craft({
	output = "etherium:etherium_sword",
	recipe = {
		{"etherium:etherium_ingot"},
		{"etherium:etherium_ingot"},
		{"group:stick"},
	},
})

minetest.register_craft({
	output = "etherium:etherium_pickaxe",
	recipe = {
		{"etherium:etherium_ingot", "etherium:etherium_ingot", "etherium:etherium_ingot"},
		{"", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "etherium:etherium_axe",
	recipe = {
		{"etherium:etherium_ingot", "etherium:etherium_ingot", ""},
		{"etherium:etherium_ingot", "group:stick", ""},
		{"", "group:stick", ""},
	},
})

minetest.register_craft({
	output = "etherium:etherium_shovel",
	recipe = {
		{"etherium:etherium_ingot"},
		{"group:stick"},
		{"group:stick"},
	},
})

minetest.register_craft({
	output = "etherium:etherium_multitool",
	recipe = {
		{"", "etherium:etherium_shovel", ""},
		{"etherium:etherium_axe", "etherium:etherium_pickaxe", "etherium:etherium_sword"}
	},
})

-- Armor
minetest.register_craft({
	output = "etherium:etherium_helmet",
	recipe = {
		{"etherium:etherium_ingot", "etherium:etherium_ingot", "etherium:etherium_ingot"},
		{"etherium:etherium_ingot", "", "etherium:etherium_ingot"},
		{"", "", ""},
	},
})

minetest.register_craft({
	output = "etherium:etherium_chestplate",
	recipe = {
		{"etherium:etherium_ingot", "", "etherium:etherium_ingot"},
		{"etherium:etherium_ingot", "etherium:etherium_ingot", "etherium:etherium_ingot"},
		{"etherium:etherium_ingot", "etherium:etherium_ingot", "etherium:etherium_ingot"}
	},
})

minetest.register_craft({
	output = "etherium:etherium_leggings",
	recipe = {
		{"etherium:etherium_ingot", "etherium:etherium_ingot", "etherium:etherium_ingot"},
		{"etherium:etherium_ingot", "", "etherium:etherium_ingot"},
		{"etherium:etherium_ingot", "", "etherium:etherium_ingot"}
	},
})

minetest.register_craft({
	output = "etherium:etherium_boots",
	recipe = {
		{"etherium:etherium_ingot", "", "etherium:etherium_ingot"},
		{"etherium:etherium_ingot", "", "etherium:etherium_ingot"}
	},
})

minetest.register_craft({
	output = "etherium:etherium_shield",
	recipe = {
		{"etherium:etherium_ingot", "etherium:etherium_ingot", "etherium:etherium_ingot"},
		{"etherium:etherium_ingot", "etherium:etherium_ingot", "etherium:etherium_ingot"},
		{"", "etherium:etherium_ingot", ""},
	},
})

minetest.register_craft({
	output = "etherium:etherium_gloves",
	recipe = {
		{"etherium:etherium_ingot", "", "etherium:etherium_ingot"},
		{"farming:string", "", "farming:string"}
	},
})

-- Armor Registration
if minetest.get_modpath("3d_armor") then
	armor:register_armor("etherium:etherium_helmet", {
		description = ("Etherium Helmet"),
		inventory_image = "etherium_etherium_helmet_inv.png",
		groups = {armor_head=1, armor_heal=20, armor_use=160, armor_fire=1},
		armor_groups = {fleshy=10},
		damage_groups = {cracky=3, snappy=1, choppy=2, level=16},
	})

	armor:register_armor("etherium:etherium_chestplate", {
		description = ("Etherium Chestplate"),
		inventory_image = "etherium_etherium_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=23, armor_use=160, armor_fire=1},
		armor_groups = {fleshy=12},
		damage_groups = {cracky=5, snappy=3, choppy=4, level=18},
	})

	armor:register_armor("etherium:etherium_leggings", {
		description = ("Etherium Leggings"),
		inventory_image = "etherium_etherium_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=22, armor_use=160, armor_fire=1},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=2, snappy=1, choppy=3, level=17},
	})

	armor:register_armor("etherium:etherium_boots", {
		description = ("Etherium Leggings"),
		inventory_image = "etherium_etherium_boots_inv.png",
		groups = {armor_feet=1, armor_heal=19, armor_use=160, armor_fire=1},
		armor_groups = {fleshy=9},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=15},
	})

	armor:register_armor("etherium:etherium_shield", {
		description = ("Etherium Shield"),
		inventory_image = "etherium_etherium_shield_inv.png",
		groups = {armor_shield=1, armor_heal=23, armor_use=160, armor_fire=1},
		armor_groups = {fleshy=12},
		damage_groups = {cracky=5, snappy=3, choppy=4, level=18},
	})

	armor:register_armor("etherium:etherium_gloves", {
		description = ("Etherium Gauntlets"),
		inventory_image = "etherium_etherium_gloves_inv.png",
		groups = {armor_hands=1, armor_heal=19, armor_use=160, armor_fire=1},
		armor_groups = {fleshy=9},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=15},
	})
end