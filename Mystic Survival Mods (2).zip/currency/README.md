currency
========

Repo for Currency Mod

# Settings

Settings with default values:
```
# After how much idle-time barter table is reset (seconds)
barter.chest.expireafter				15 * 60
```
