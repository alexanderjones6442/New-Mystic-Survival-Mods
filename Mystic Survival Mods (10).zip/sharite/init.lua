-----------------
-- Ores/Blocks --
-----------------
minetest.register_node("sharite:sharite_block", {
	description = ("Sharite Block"),
	tiles = {"sharite_sharite_block.png"},
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("sharite:sharite_ore", {
	description = ("Sharite Ore"),
	tiles = {"default_stone.png^sharite_sharite_ore.png"},
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "sharite:sharite_fragment",
})

-----------
-- Tools --
-----------
minetest.register_tool("sharite:sharite_sword", {
	description = ("Sharite Sword"),
	inventory_image = "sharite_sharite_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.4,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.35, [2]=0.26, [3]=0.2}, uses=3750, maxlevel=3},
		},
		damage_groups = {fleshy=40},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("sharite:sharite_pickaxe", {
	description = ("Sharite Pickaxe"),
	inventory_image = "sharite_sharite_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			cracky={times={[1]=0.35, [2]=0.26, [3]=0.2}, uses=3750, maxlevel=3},
		},
		damage_groups = {fleshy=38},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1}
})

minetest.register_tool("sharite:sharite_axe", {
	description = ("Sharite Axe"),
	inventory_image = "sharite_sharite_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=0.35, [2]=0.26, [3]=0.2}, uses=3750, maxlevel=3},
		},
		damage_groups = {fleshy=39},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {axe = 1},
})

minetest.register_tool("sharite:sharite_shovel", {
	description = ("Sharite Shovel"),
	inventory_image = "sharite_sharite_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level=1,
		groupcaps={
			crumbly={times={[1]=0.35, [2]=0.26, [3]=0.2}, uses=3750, maxlevel=3},
		},
		damage_groups = {fleshy=37},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel = 1},
})

------------
-- Mapgen --
------------

-- Sharite Ore

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "sharite:sharite_ore",
		wherein        = "default:stone",
		clust_scarcity = 35 * 35 * 35,
		clust_num_ores = 1,
		clust_size     = 1,
		y_max          = -10000,
		y_min          = -20000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "sharite:sharite_ore",
		wherein        = "default:stone",
		clust_scarcity = 32 * 32 * 32,
		clust_num_ores = 2,
		clust_size     = 2,
		y_max          = -15000,
		y_min          = -25000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "sharite:sharite_ore",
		wherein        = "default:stone",
		clust_scarcity = 30 * 30 * 30,
		clust_num_ores = 3,
		clust_size     = 3,
		y_max          = -15000,
		y_min          = -31000,
	})
-----------------
-- Craft Items --
-----------------
minetest.register_craftitem("sharite:sharite_fragment", {
	description = ("Sharite Fragment"),
	inventory_image = "sharite_sharite_fragment.png"
})
------------
-- Crafts --
------------

-- Block
minetest.register_craft({
	output = "sharite:sharite_block",
	recipe = {
		{"sharite:sharite_fragment", "sharite:sharite_fragment", "sharite:sharite_fragment"},
		{"sharite:sharite_fragment", "sharite:sharite_fragment", "sharite:sharite_fragment"},
		{"sharite:sharite_fragment", "sharite:sharite_fragment", "sharite:sharite_fragment"},
	},
})

minetest.register_craft({
	output = "sharite:sharite_fragment 9",
	recipe = {
		{"sharite:sharite_block"},
	},
})
-- Tools

minetest.register_craft({
	output = "sharite:sharite_sword",
	recipe = {
		{"sharite:sharite_fragment"},
		{"sharite:sharite_fragment"},
		{"group:stick"},
	},
})

minetest.register_craft({
	output = "sharite:sharite_pickaxe",
	recipe = {
		{"sharite:sharite_fragment", "sharite:sharite_fragment", "sharite:sharite_fragment"},
		{"", "group:stick", ""},
		{"", "group:stick", ""},
	},
})

minetest.register_craft({
	output = "sharite:sharite_axe",
	recipe = {
		{"sharite:sharite_fragment", "sharite:sharite_fragment"},
		{"sharite:sharite_fragment", "group:stick"},
		{"", "group:stick"},
	},
})

minetest.register_craft({
	output = "sharite:sharite_shovel",
	recipe = {
		{"sharite:sharite_fragment"},
		{"group:stick"},
		{"group:stick"},
	},
})

-- Armor
minetest.register_craft({
	output = "sharite:sharite_helmet",
	recipe = {
		{"sharite:sharite_fragment", "sharite:sharite_fragment", "sharite:sharite_fragment"},
		{"sharite:sharite_fragment", "", "sharite:sharite_fragment"},
	},
})

minetest.register_craft({
	output = "sharite:sharite_chestplate",
	recipe = {
		{"sharite:sharite_fragment", "", "sharite:sharite_fragment"},
		{"sharite:sharite_fragment", "sharite:sharite_fragment", "sharite:sharite_fragment"},
		{"sharite:sharite_fragment", "sharite:sharite_fragment", "sharite:sharite_fragment"},
	},
})

minetest.register_craft({
	output = "sharite:sharite_leggings",
	recipe = {
		{"sharite:sharite_fragment", "sharite:sharite_fragment", "sharite:sharite_fragment"},
		{"sharite:sharite_fragment", "", "sharite:sharite_fragment"},
		{"sharite:sharite_fragment", "", "sharite:sharite_fragment"},
	},
})

minetest.register_craft({
	output = "sharite:sharite_boots",
	recipe = {
		{"sharite:sharite_fragment", "", "sharite:sharite_fragment"},
		{"sharite:sharite_fragment", "", "sharite:sharite_fragment"},
	},
})
----------------------
-- 3D Armor support --
----------------------
if minetest.get_modpath("3d_armor") then
	armor:register_armor("sharite:sharite_helmet", {
		description = ("Sharite Helmet"),
		inventory_image = "sharite_sharite_helmet_inv.png",
		groups = {armor_head=1, armor_heal=30, armor_use=60, armor_water=1},
		armor_groups = {fleshy=18},
		damage_groups = {cracky=2, snappy=1, level=50},
	})

	armor:register_armor("sharite:sharite_chestplate", {
		description = ("Sharite Chestplate"),
		inventory_image = "sharite_sharite_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=50, armor_use=60, armor_water=1},
		armor_groups = {fleshy=20},
		damage_groups = {cracky=2, snappy=1, level=70},
	})

	armor:register_armor("sharite:sharite_leggings", {
		description = ("Sharite Leggings"),
		inventory_image = "sharite_sharite_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=40, armor_use=60, armor_water=1},
		armor_groups = {fleshy=19},
		damage_groups = {cracky=2, snappy=1, level=60},
	})

	armor:register_armor("sharite:sharite_boots", {
		description = ("Sharite Boots"),
		inventory_image = "sharite_sharite_boots_inv.png",
		groups = {armor_feet=1, armor_heal=20, armor_use=60, armor_water=1, physics_speed=1.25, physics_jump=0.75},
		armor_groups = {fleshy=17},
		damage_groups = {cracky=2, snappy=1, level=40},
	})

	armor:register_armor("sharite:sharite_shield", {
		description = ("Sharite Shield"),
		inventory_image = "sharite_sharite_shield_inv.png",
		groups = {armor_shield=1, armor_heal=50, armor_use=60, armor_water=1},
		armor_groups = {fleshy=20},
		damage_groups = {cracky=2, snappy=1, level=75},
	})

end