local cheap_items = {
    {"opal:opal"},
    {"opal:opal_block"},
    {"opal:opal_glass"},
    {"opal:opal_brick"},
    {"opal:opal_brick_cracked"},
    {"opal:opal_pillar"},
    {"opal:opal_pillar_cracked"},
}

lootchests.add_to_loot_table("lootchests_default:urn", cheap_items)