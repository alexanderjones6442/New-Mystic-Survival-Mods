local expensive_items = {
    {"ardelion:ardelion_crystal"},
    {"ardelion:ardelion_block"},
    {"ardelion:ardelion_sword"},
    {"ardelion:ardelion_pickaxe"},
    {"ardelion:ardelion_axe"},
    {"ardelion:ardelion_shovel"},
    {"ardelion:ardelion_helmet"},
    {"ardelion:ardelion_chestplate"},
    {"ardelion:ardelion_leggings"},
    {"ardelion:ardelion_boots"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)