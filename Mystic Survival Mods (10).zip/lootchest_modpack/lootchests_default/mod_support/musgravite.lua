local expensive_items = {
    {"musgravite:musgravite_gem"},
    {"musgravite:musgravite_block"},
    {"musgravite:musgravite_sword"},
    {"musgravite:musgravite_pickaxe"},
    {"musgravite:musgravite_axe"},
    {"musgravite:musgravite_shovel"},
    {"musgravite:musgravite_helmet"},
    {"musgravite:musgravite_chestplate"},
    {"musgravite:musgravite_leggings"},
    {"musgravite:musgravite_boots"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)