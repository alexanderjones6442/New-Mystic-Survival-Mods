local expensive_items = {
    {"lavastuff:ingot"},
    {"lavastuff:block"},
    {"lavastuff:sword"},
    {"lavastuff:pick"},
    {"lavastuff:axe"},
    {"lavastuff:shovel"},
    {"lavastuff:helmet_lava"},
    {"lavastuff:chestplate_lava"},
    {"lavastuff:leggings_lava"},
    {"lavastuff:boots_lava"},
    {"lavastuff:shield_lava"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)