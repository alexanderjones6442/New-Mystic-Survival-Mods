local expensive_items = {
    {"synlium:synlium_ingot"},
    {"synlium:synlium_block"},
    {"synlium:synlium_sword"},
    {"synlium:synlium_pickaxe"},
    {"synlium:synlium_axe"},
    {"synlium:synlium_shovel"},
    {"synlium:synlium_helmet"},
    {"synlium:synlium_chestplate"},
    {"synlium:synlium_leggings"},
    {"synlium:synlium_boots"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)