local expensive_items = {
    {"ruby:ruby"},
    {"ruby:ruby_block"},
    {"ruby:ruby_sword"},
    {"ruby:ruby_pickaxe"},
    {"ruby:ruby_axe"},
    {"ruby:ruby_shovel"},
    {"ruby:ruby_helmet"},
    {"ruby:ruby_chestplate"},
    {"ruby:ruby_leggings"},
    {"ruby:ruby_boots"},
    {"ruby:ruby_shield"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)