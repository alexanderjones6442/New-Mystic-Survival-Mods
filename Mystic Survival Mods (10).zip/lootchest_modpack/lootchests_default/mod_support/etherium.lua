local expensive_items = {
    {"etherium:etherium_ingot"},
    {"etherium:etherium_block"},
    {"etherium:etherium_lump"},
    {"etherium:etherium_sword"},
    {"etherium:etherium_pickaxe"},
    {"etherium:etherium_axe"},
    {"etherium:etherium_shovel"},
    {"etherium:etherium_helmet"},
    {"etherium:etherium_chestplate"},
    {"etherium:etherium_leggings"},
    {"etherium:etherium_boots"},
    {"etherium:etherium_shield"},
    {"etherium:etherium_gloves"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)