local expensive_items = {
    {"beryl:beryl"},
    {"beryl:beryl_block"},
    {"beryl:beryl_sword"},
    {"beryl:beryl_pickaxe"},
    {"beryl:beryl_axe"},
    {"beryl:beryl_shovel"},
    {"beryl:beryl_helmet"},
    {"beryl:beryl_chestplate"},
    {"beryl:beryl_leggings"},
    {"beryl:beryl_boots"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)