local_expensive_items = {
    {"helixite:helixite_crystal"},
    {"helixite:helixite_block"},
    {"helixite:helixite_sword"},
    {"helixite:helixite_pickaxe"},
    {"helixite:helixite_axe"},
    {"helixite:helixite_shovel"},
    {"helixite:helixite_helmet"},
    {"helixite:helixite_chestplate"},
    {"helixite:helixite_leggings"},
    {"helixite:helixite_boots"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)