local expensive_items = {
    {"cerennium:cerennium_shard"},
    {"cerennium:cerennium_block"},
    {"cerennium:cerennium_sword"},
    {"cerennium:cerennium_pickaxe"},
    {"cerennium:cerennium_axe"},
    {"cerennium:cerennium_shovel"},
    {"cerennium:cerennium_helmet"},
    {"cerennium:cerennium_chestplate"},
    {"cerennium:cerennium_leggings"},
    {"cerennium:cerennium_boots"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)