local expensive_items = {
    {"myrane:myrane_gem"},
    {"myrane:myrane_block"},
    {"myrane:myrane_sword"},
    {"myrane:myrane_pickaxe"},
    {"myrane:myrane_axe"},
    {"myrane:myrane_shovel"},
    {"myrane:myrane_helmet"},
    {"myrane:myrane_chestplate"},
    {"myrane:myrane_leggings"},
    {"myrane:myrane_boots"},
    {"myrane:myrane_shield"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)