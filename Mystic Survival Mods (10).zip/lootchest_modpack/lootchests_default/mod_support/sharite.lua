local expensive_items = {
    {"sharite:sharite_fragment"},
    {"sharite:sharite_block"},
    {"sharite:sharite_sword"},
    {"sharite:sharite_pickaxe"},
    {"sharite:sharite_axe"},
    {"sharite:sharite_shovel"},
    {"sharite:sharite_helmet"},
    {"sharite:sharite_chestplate"},
    {"sharite:sharite_leggings"},
    {"sharite:sharite_boots"},
    {"sharite:sharite_shield"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)