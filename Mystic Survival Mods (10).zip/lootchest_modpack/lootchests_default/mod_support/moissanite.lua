local expensive_items = {
    {"moissanite:moissanite_gem"},
    {"moissanite:moissanite_block"},
    {"moissanite:moissanite_sword"},
    {"moissanite:moissanite_pickaxe"},
    {"moissanite:moissanite_axe"},
    {"moissanite:moissanite_shovel"},
    {"moissanite:moissanite_helmet"},
    {"moissanite:moissanite_chestplate"},
    {"moissanite:moissanite_leggings"},
    {"moissanite:moissanite_boots"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)