local expensive_items = {
    {"amethyst:amethyst"},
    {"amethyst:amethyst_sword"},
    {"amethyst:amethyst_pickaxe"},
    {"amethyst:amethyst_axe"},
    {"amethyst:amethyst_shovel"},
    {"amethyst:amethyst_helmet"},
    {"amethyst:amethyst_chestplate"},
    {"amethyst:amethyst_leggings"},
    {"amethyst:amethyst_boots"},
    {"amethyst:amethyst_shield"},
    {"amethyst:amethyst_block"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)