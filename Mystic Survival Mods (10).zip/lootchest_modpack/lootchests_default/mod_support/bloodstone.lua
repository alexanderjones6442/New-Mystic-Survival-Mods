local expensive_items = {
    {"bloodstone:bloodstone"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)