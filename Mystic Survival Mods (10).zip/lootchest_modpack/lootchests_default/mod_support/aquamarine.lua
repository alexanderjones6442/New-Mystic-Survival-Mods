local cheap_items = {
    {"aquamarine:aquamarine"},
    {"aquamarine:aquamarine_block"},
    {"aquamarine:aquamarine_sword"},
    {"aquamarine:aquamarine_pickaxe"},
    {"aquamarine:aquamarine_axe"},
    {"aquamarine:aquamarine_shovel"},
    {"aquamarine:aquamarine_helmet"},
    {"aquamarine:aquamarine_chestplate"},
    {"aquamarine:aquamarine_leggings"},
    {"aquamarine:aquamarine_boots"},
    {"aquamarine:aquamarine_shield"},
}

lootchests.add_to_loot_table("lootchests_default:urn", cheap_items)