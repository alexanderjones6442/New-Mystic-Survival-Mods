local medium_items = {
    {"prismarine:prismarine_shard"},
    {"prismarine:prismarine_block"},
    {"prismarine:prismarine_carved"},
}

lootchests.add_to_loot_table("lootchests_default:ocean_chest", medium_items)