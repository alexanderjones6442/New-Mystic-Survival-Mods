local expensive_items = {
    {"rubenite:rubenite_crystal"},
    {"rubenite:rubenite_block"},
    {"rubenite:rubenite_sword"},
    {"rubenite:rubenite_pickaxe"},
    {"rubenite:rubenite_axe"},
    {"rubenite:rubenite_shovel"},
    {"rubenite:rubenite_helmet"},
    {"rubenite:rubenite_chestplate"},
    {"rubenite:rubenite_leggings"},
    {"rubenite:rubenite_boots"},
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items}