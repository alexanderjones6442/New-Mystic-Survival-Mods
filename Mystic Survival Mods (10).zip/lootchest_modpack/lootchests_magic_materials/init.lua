local path = minetest.get_modpath("lootchests_magic_materials")
dofile(path .. "/item_tables.lua")
dofile(path .. "/chests.lua")
