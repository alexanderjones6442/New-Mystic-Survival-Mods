dofile(minetest.get_modpath("lootchests").."/api.lua")
