---- GOLEM   ( BOSS 2 )------------------------------------------------------------------------------------------------------
-- sound : https://freesound.org/people/Debsound/sounds/250148/

mobs:register_mob("golem:golem", {
	nametag = "Golem Boss" ,
	type = "monster",
	passive = false,
	attack_npcs = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 6,
	damage = 12,
	hp_min = 500,
	hp_max = 500,
	armor = 80,
	visual = "mesh",
	visual_size = {x = 17, y = 17},
	mesh = "golem.b3d",
	collisionbox = {-1.0, -0.8, -1.0, 1.0, 2.2, 1.0},
	--rotate = 180,
	textures = {
		{"golem.png"},
	},
	glow = 3,
	blood_texture = "faisca.png",
	makes_footstep_sound = true,
	sounds = {
		attack = "monster",
		--death = "",
	},
	walk_velocity = 2,
	run_velocity = 4,
	jump_height = 5,
	stepheight = 3.0,
	floats = 0,
	view_range = 35,
	drops = {
		--{name = " ", chance = 2, min = 1, max = 1},
		--{name = "skullkingsitems:golem_trophy", chance = 1, min = 1, max = 1},
		{name = "default:diamondblock", chance = 2, min = 1, max = 2},

	},
	water_damage = 0,
	lava_damage = 1,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 1,
		stand_end = 10,
		walk_start = 20,
		walk_end = 60,
		run_start = 80,
		run_end = 120,
		punch_start = 140,
		punch_end = 180,
	},

	on_spawn = function ()
	minetest.chat_send_all ("Golem Summoned ...")
	end,
	
	
	on_die = function(self, pos) 
	for _,players in pairs(minetest.get_objects_inside_radius(pos,55)) do 
			if players:is_player() then 
				awards.unlock(players:get_player_name(), "boss_2") 
			end
		end

		 minetest.add_particlespawner({
            amount = 50, 
            time = 2, 
            minpos = {x = pos.x - 2, y = pos.y, z = pos.z - 2},
            maxpos = {x = pos.x + 2, y = pos.y + 2, z = pos.z + 2},
            minvel = {x = -3, y = -3, z = -3}, 
            maxvel = {x = 3, y = 3, z = 3}, 
            minacc = {x = 0, y = -1, z = 0},
            maxacc = {x = 0, y = -1, z = 0}, 
            minexptime = 3, 
            maxexptime = 6, 
            minsize = 4,
            maxsize = 8,
            collisiondetection = false,
            vertical = false, 
            texture = "tnt_smoke.png", 
            glow = 14, 
        })

	end


})


mobs:spawn({
	name = "golem:golem",
	nodes = {"default:stone"},
	max_light = 7,
	interval = 60,
  chance = 150000,
	max_height = -750,
	min_height = -850,
})


mobs:register_egg("golem:golem", "Golem", "egggoelm.png", 1)
--core.register_alias("golem:golem", "spawneggs:golem")
