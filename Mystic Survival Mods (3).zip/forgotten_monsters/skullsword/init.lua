-- SOUNDS LINK :
-- Bones : https://freesound.org/people/spookymodem/sounds/202091/
-- sword : https://freesound.org/people/Wdfourtee/sounds/192055/



local skullnods = {
"everness:dirt_with_cursed_grass",
"everness:cursed_stone_engraved",

}


---- SKULL SWORD  ------------------------------------------------------------------------------------------------------

mobs:register_mob("skullsword:ssword", {
	--nametag = "Skull Sword" ,
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 4,
	hp_min = 15,
	hp_max = 15,
	armor = 100,
	collisionbox = {-0.4, -0, -0.4, 0.4, 1.8, 0.4},
	visual = "mesh",
	visual_size = {x = 9, y = 9},
	mesh = "skull_sword_anim.b3d",
	--rotate = 180,
	textures = {
		{"skull_sword.png"},
	},
	--glow = 4,
	blood_texture = "bonex.png",
	makes_footstep_sound = true,
	sounds = {
		attack = "sword_skull",
		death = "falling_bones",
	},
	walk_velocity = 1,
	run_velocity = 5,
	jump_height = 2,
	stepheight = 1.1,
	floats = 0,
	view_range = 25,
	drops = {
		{name = "skullkingsitems:bone", chance = 1, min = 1, max = 2},
		{name = "default:sword_stone", chance = 5, min = 1, max = 1},
		{name = "default:iron_lump", chance = 3, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 1,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 30,
		stand_start = 1,
		stand_end = 20,
		walk_start = 30,
		walk_end = 70,
		run_start = 80,
		run_end = 90,
		--punch_start = 80,
		--punch_end = 90,
	},
})



mobs:spawn({
	name = "skullsword:ssword",
	nodes = skullnods,
	min_light = 0,
	max_light = 14,
	chance = 7000,
	--min_height = 0,
	--max_height = 200,
	max_height = 200,
})


mobs:register_egg("skullsword:ssword", "Skull Sword", "eggsskullsword.png", 1)
core.register_alias("skullsword:ssword", "spawneggs:ssword")
