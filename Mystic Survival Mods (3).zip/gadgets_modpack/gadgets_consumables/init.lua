local path = minetest.get_modpath("gadgets_consumables")
dofile(path .. "/potions.lua")
dofile(path .. "/specials.lua")