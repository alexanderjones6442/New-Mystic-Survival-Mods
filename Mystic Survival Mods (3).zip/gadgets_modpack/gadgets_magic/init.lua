local path = minetest.get_modpath("gadgets_magic")
dofile(path .. "/spellbooks.lua")
dofile(path .. "/staves.lua")
dofile(path .. "/nodes.lua")