-----------------
-- Ores/Blocks --
-----------------
minetest.register_node("aurenite:aurenite_block", {
	description = ("Aurenite Block"),
	tiles = {"aurenite_aurenite_block.png"},
	is_ground_content = true,
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("aurenite:aurenite_ore", {
	description = ("Aurenite Ore"),
	tiles = {"default_stone.png^aurenite_aurenite_ore.png"},
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "aurenite:aurenite_lump",
})

-----------
-- Tools --
-----------
minetest.register_tool("aurenite:aurenite_sword", {
	description = ("Aurenite Sword"),
	inventory_image = "aurenite_aurenite_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.4,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.2, [2]=0.15, [3]=0.1}, uses=5475, maxlevel=3},
		},
		damage_groups = {fleshy=75},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("aurenite:aurenite_pickaxe", {
	description = ("Aurenite Pickaxe"),
	inventory_image = "aurenite_aurenite_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			cracky={times={[1]=0.2, [2]=0.15, [3]=0.1}, uses=5475, maxlevel=3},
		},
		damage_groups = {fleshy=65},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1}
})

minetest.register_tool("aurenite:aurenite_axe", {
	description = ("Aurenite Axe"),
	inventory_image = "aurenite_aurenite_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=0.2, [2]=0.15, [3]=0.1}, uses=5475, maxlevel=3},
		},
		damage_groups = {fleshy=70},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {axe = 1},
})

minetest.register_tool("aurenite:aurenite_shovel", {
	description = ("Aurenite Shovel"),
	inventory_image = "aurenite_aurenite_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level=1,
		groupcaps={
			crumbly={times={[1]=0.2, [2]=0.15, [3]=0.1}, uses = 5475, maxlevel=3},
		},
		damage_groups = {fleshy=60},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel = 1},
})

------------
-- Mapgen --
------------

-- Aurenite Ore

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "aurenite:aurenite_ore",
		wherein        = "default:stone",
		clust_scarcity = 80 * 80 * 80,
		clust_num_ores = 1,
		clust_size     = 1,
		y_max          = -10000,
		y_min          = -20000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "aurenite:aurenite_ore",
		wherein        = "default:stone",
		clust_scarcity = 70 * 70 * 70,
		clust_num_ores = 1,
		clust_size     = 1,
		y_max          = -15000,
		y_min          = -25000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "aurenite:aurenite_ore",
		wherein        = "default:stone",
		clust_scarcity = 60 * 60 * 60,
		clust_num_ores = 2,
		clust_size     = 2,
		y_max          = -15000,
		y_min          = -31000,
	})
-----------------
-- Craft Items --
-----------------
minetest.register_craftitem("aurenite:aurenite_lump", {
	description = ("Aurenite Lump"),
	inventory_image = "aurenite_aurenite_lump.png"
})

minetest.register_craftitem("aurenite:aurenite_ingot", {
	description = ("Aurenite Ingot"),
	inventory_image = "aurenite_aurenite_ingot.png"
})

------------
-- Crafts --
------------

-- Block
minetest.register_craft({
	output = "aurenite:aurenite_block",
	recipe = {
		{"aurenite:aurenite_ingot", "aurenite:aurenite_ingot", "aurenite:aurenite_ingot"},
		{"aurenite:aurenite_ingot", "aurenite:aurenite_ingot", "aurenite:aurenite_ingot"},
		{"aurenite:aurenite_ingot", "aurenite:aurenite_ingot", "aurenite:aurenite_ingot"},
	},
})

minetest.register_craft({
	output = "aurenite:aurenite_ingot 9",
	recipe = {
		{"aurenite:aurenite_block"},
	},
})

-- Smelting Recipe
minetest.register_craft({
	type = "cooking",
	output = "aurenite:aurenite_ingot",
	recipe = "aurenite:aurenite_lump",
	cooktime = 15,
})

-- Tools

minetest.register_craft({
	output = "aurenite:aurenite_sword",
	recipe = {
		{"aurenite:aurenite_ingot"},
		{"aurenite:aurenite_ingot"},
		{"default:steel_ingot"},
	},
})

minetest.register_craft({
	output = "aurenite:aurenite_pickaxe",
	recipe = {
		{"aurenite:aurenite_ingot", "aurenite:aurenite_ingot", "aurenite:aurenite_ingot"},
		{"", "default:steel_ingot", ""},
		{"", "default:steel_ingot", ""},
	},
})

minetest.register_craft({
	output = "aurenite:aurenite_axe",
	recipe = {
		{"aurenite:aurenite_ingot", "aurenite_aurenite_ingot", ""},
		{"aurenite:aurenite_ingot", "default:steel_ingot", ""},
		{"", "default:steel_ingot", ""},
	},
})

minetest.register_craft({
	output = "aurenite:aurenite_shovel",
	recipe = {
		{"aurenite:aurenite_ingot"},
		{"default:steel_ingot"},
		{"default:steel_ingot"},
	},
})

-- Armor
minetest.register_craft({
	output = "aurenite:aurenite_helmet",
	recipe = {
		{"aurenite:aurenite_ingot", "aurenite:aurenite_ingot", "aurenite:aurenite_ingot"},
		{"aurenite:aurenite_ingot", "", "aurenite:aurenite_ingot"},
		{"", "", ""}
	},
})

minetest.register_craft({
	output = "aurenite:aurenite_chestplate",
	recipe = {
		{"aurenite:aurenite_ingot", "", "aurenite:aurenite_ingot"},
		{"aurenite:aurenite_ingot", "aurenite:aurenite_ingot", "aurenite:aurenite_ingot"},
		{"aurenite:aurenite_ingot", "aurenite:aurenite_ingot", "aurenite:aurenite_ingot"},
	},
})

minetest.register_craft({
	output = "aurenite:aurenite_leggings",
	recipe = {
		{"aurenite:aurenite_ingot", "aurenite:aurenite_ingot", "aurenite:aurenite_ingot"},
		{"aurenite:aurenite_ingot", "", "aurenite:aurenite_ingot"},
		{"aurenite:aurenite_ingot", "", "aurenite:aurenite_ingot"},
	},
})

minetest.register_craft({
	output = "aurenite:aurenite_boots",
	recipe = {
		{"aurenite:aurenite_ingot", "", "aurenite:aurenite_ingot"},
		{"aurenite:aurenite_ingot", "", "aurenite:aurenite_ingot"},
		{"", "", "",}
	},
})
----------------------
-- 3D Armor support --
----------------------
if minetest.get_modpath("3d_armor") then
	armor:register_armor("aurenite:aurenite_helmet", {
		description = ("Aurenite Helmet"),
		inventory_image = "aurenite_aurenite_helmet_inv.png",
		groups = {armor_head=1, armor_heal=90, armor_use=20, armor_fire=3, physics_jump=1},
		armor_groups = {fleshy=24},
		damage_groups = {cracky=2, snappy=1, level=90},
	})

	armor:register_armor("aurenite:aurenite_chestplate", {
		description = ("Aurenite Chestplate"),
		inventory_image = "aurenite_aurenite_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=110, armor_use=20, armor_fire=3, physics_jump=1.5},
		armor_groups = {fleshy=26},
		damage_groups = {cracky=2, snappy=1, level=100},
	})

	armor:register_armor("aurenite:aurenite_leggings", {
		description = ("Aurenite Leggings"),
		inventory_image = "aurenite_aurenite_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=100, armor_use=20, armor_fire=3, physics_jump=1.25},
		armor_groups = {fleshy=25},
		damage_groups = {cracky=2, snappy=1, level=100},
	})

	armor:register_armor("aurenite:aurenite_boots", {
		description = ("Aurenite Boots"),
		inventory_image = "aurenite_aurenite_boots_inv.png",
		groups = {armor_feet=1, armor_heal=80, armor_use=20, armor_fire=3, physics_speed=2, physics_jump=0.75},
		armor_groups = {fleshy=23},
		damage_groups = {cracky=2, snappy=1, level=90},
	})

end