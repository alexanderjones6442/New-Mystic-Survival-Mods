

minetest.register_tool("bloodbane:sword_bloodbane", {
	description = ("Blood Bane Sword"),
	inventory_image = "bloodbane_tool_bloodbanesword.png",
	tool_capabilities = {
		full_punch_interval = 0.001,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.00000001, [2]=0.0000000001, [3]=0.0000000000001}, uses=0, maxlevel=3},
		},
		damage_groups = {fleshy=32767},
	},
	range = 350,
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1, not_in_creative_inventory = 1}
})
