local path = minetest.get_modpath("bweapons_api")
dofile(path .. "/api.lua")
