-- Blocks --

minetest.register_node("bloodstone:bloodstone_ore", {
	description = ("Bloodstone Ore"),
	tiles = {"default_stone.png^bloodstone_bloodstone_ore.png"},
	is_ground_content = true,
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "bloodstone:bloodstone",
})

-- Gem --

minetest.register_craftitem("bloodstone:bloodstone", {
	description = ("Bloodstone"),
	inventory_image = "bloodstone_bloodstone.png",
})

-- Ore --

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "bloodstone:bloodstone_ore",
		wherein        = "default:stone",
		clust_scarcity = 9 * 9 * 9,
		clust_num_ores = 4,
		clust_size     = 3,
		y_max          = -80,
		y_min          = -500,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "bloodstone:bloodstone_ore",
		wherein        = "default:stone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 5,
		clust_size     = 4,
		y_max          = -250,
		y_min          = -31000,
	})

-- Crafts --
minetest.register_craft({
	output = "bloodstone:healing_staff",
	recipe = {
		{"", "bloodstone:bloodstone", ""},
		{"bloodstone:bloodstone", "default:obsidian_shard", "bloodstone:bloodstone"},
		{"", "default:obsidian_shard", ""}
	},
})

minetest.register_tool("bloodstone:healing_staff", {
    description = "Healing Staff",
    inventory_image = "bloodstone_healing_staff.png",
    wield_scale = { x = 2, y = 2, z = 1 },
    wield_image = "bloodstone_healing_staff.png",
    on_use = function(itemstack, user, pointed_thing)
        local pos = user:get_pos()
        local wielded_item = user:get_wielded_item()
        local meta = wielded_item:get_meta()
        
        if pointed_thing.type == "object" then
            local object = pointed_thing.ref
            if object:is_player() then
                local player_name = object:get_player_name()
                local hp = object:get_hp()
                if hp < 20 then
                    object:set_hp(hp + 5)
                    minetest.sound_play("healing_sound", {pos = pos, max_hear_distance = 10})
                end
            end
        elseif pointed_thing.type == "node" then
            local objects = minetest.get_objects_inside_radius(pointed_thing.above, 4)
            for _, object in ipairs(objects) do
                if object:is_player() then
                    local player_name = object:get_player_name()
                    local hp = object:get_hp()
                    if hp < 20 then
                        object:set_hp(hp + 5)
                        minetest.sound_play("heal", {pos = pos, max_hear_distance = 20})
                        minetest.add_particlespawner({
                            amount = 20,
                            time = 0.1,
                            minpos = {x = pointed_thing.above.x - 0.5, y = pointed_thing.above.y, z = pointed_thing.above.z - 0.5},
                            maxpos = {x = pointed_thing.above.x + 0.5, y = pointed_thing.above.y + 1, z = pointed_thing.above.z + 0.5},
                            minvel = {x = -0.5, y = 2, z = -0.5},
                            maxvel = {x = 0.5, y = 3, z = 0.5},
                            minacc = {x = 0, y = -1, z = 0},
                            maxacc = {x = 0, y = -1, z = 0},
                            minexptime = 1,
                            maxexptime = 2,
                            minsize = 2,
                            maxsize = 4,
                            collisiondetection = true,
                            collision_removal = true,
                            vertical = true,
                            texture = "bloodstone_bloodstone_heal_particle.png",
                        })
                    end
                end
            end
        end
        return itemstack
    end,
})