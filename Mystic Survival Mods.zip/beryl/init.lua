-- Ore and Block
minetest.register_node("beryl:beryl_ore", {
	description = ("Beryl Ore"),
	tiles = {"default_stone.png^beryl_beryl_ore.png"},
	is_ground_content = true,
	groups = {cracky = 2, level = 2},
	sounds = default.node_sound_stone_defaults(),
	drop = "beryl:beryl",
})

minetest.register_node("beryl:deepslate_beryl_ore", {
	description = ("Beryl Deepslate Ore"),
	tiles = {"beryl_beryl_ore_2.png"},
	is_ground_content = false,
	groups = {cracky = 2, level = 2},
	sounds = default.node_sound_stone_defaults(),
	drop = "beryl:beryl",
})

minetest.register_node("beryl:beryl_block", {
	description = ("Beryl Block"),
	tiles = {"beryl_beryl_block.png"},
	groups = {cracky = 2, level = 2},
	sounds = default.node_sound_stone_defaults(),
})


-- Tools
minetest.register_tool("beryl:beryl_sword", {
	description = ("Beryl Sword"),
	inventory_image = "beryl_beryl_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level = 1,
		groupcaps={
			snappy={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses=275, maxlevel=3},
		},
		damage_groups = {fleshy=7},
	},
	sound = {breaks = default_tool_breaks},
	groups = {sword = 1},
})

minetest.register_tool("beryl:beryl_pickaxe", {
	description = ("Beryl Pickaxe"),
	inventory_image = "beryl_beryl_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level = 1,
		groupcaps={
			cracky={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses=275, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
	sound = {breaks = default_tool_breaks},
	groups = {pickaxe = 1},
})

minetest.register_tool("beryl:beryl_axe", {
	description = ("Beryl Axe"),
	inventory_image = "beryl_beryl_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level = 1,
		groupcaps = {
			choppy={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses=275, maxlevel=3},
		},
		damage_groups = {fleshy=6},
	},
	sound = {breaks = default_tool_breaks},
	groups = {axe = 1},
})

minetest.register_tool("beryl:beryl_shovel", {
	description = ("Beryl Shovel"),
	inventory_image = "beryl_beryl_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level = 1,
		groupcaps = {
			crumbly={times={[1]=0.3, [2]=0.2, [3]=0.1}, uses=275, maxlevel = 3},
		},
		damage_groups = {fleshy=4},
	},
	sound = {breaks = default_tool_breaks},
	groups = {shovel = 1},
})

-- Ore Mapgen
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "beryl:beryl_ore",
		wherein        = "default:stone",
		clust_scarcity = 16 * 16 * 16,
		clust_num_ores = 4,
		clust_size     = 4,
		y_max          = -128,
		y_min          = -1500,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "beryl:beryl_ore",
		wherein        = "default:stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 5,
		clust_size     = 5,
		y_max          = -256,
		y_min          = -28000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "beryl:beryl_ore",
		wherein        = "deepslate:deepslate",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 6,
		clust_size     = 6,
		y_max          = -10000,
		y_min          = -31000,
	})


-- Crafts
minetest.register_craftitem("beryl:beryl", {
	description = ("Beryl"),
	inventory_image = "beryl_beryl.png"
})

minetest.register_craft({
	output = "beryl:beryl_block",
	recipe  = {
		{"beryl:beryl", "beryl:beryl", "beryl:beryl"},
		{"beryl:beryl", "beryl:beryl", "beryl:beryl"},
		{"beryl:beryl", "beryl:beryl", "beryl:beryl"}
	},
})

minetest.register_craft({
	output = "beryl:beryl 9",
	recipe = {
		{"beryl:beryl_block"},
	},
})

minetest.register_craft({
	output = "beryl:beryl_sword",
	recipe = {
		{"beryl:beryl"},
		{"beryl:beryl"},
		{"group:stick"}
	},
})

minetest.register_craft({
	output = "beryl:beryl_pickaxe",
	recipe = {
		{"beryl:beryl", "beryl:beryl", "beryl:beryl"},
		{"", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "beryl:beryl_axe",
	recipe = {
		{"beryl:beryl", "beryl:beryl", ""},
		{"beryl:beryl", "group:stick", ""},
		{"", "group:stick", ""}
	},
})

minetest.register_craft({
	output = "beryl:beryl_shovel",
	recipe = {
		{"beryl:beryl"},
		{"group:stick"},
		{"group:stick"}
	},
})

minetest.register_craft({
	output = "beryl:beryl_helmet",
	recipe = {
		{"beryl:beryl", "beryl:beryl", "beryl:beryl"},
		{"beryl:beryl", "", "beryl:beryl"},
		{"", "", ""}
	},
})

minetest.register_craft({
	output = "beryl:beryl_chestplate",
	recipe = {
		{"beryl:beryl", "", "beryl:beryl"},
		{"beryl:beryl", "beryl:beryl", "beryl:beryl"},
		{"beryl:beryl", "beryl:beryl", "beryl:beryl"}
	},
})

minetest.register_craft({
	output = "beryl:beryl_leggings",
	recipe = {
		{"beryl:beryl", "beryl:beryl", "beryl:beryl"},
		{"beryl:beryl", "", "beryl:beryl"},
		{"beryl:beryl", "", "beryl:beryl"}
	},
})

minetest.register_craft({
	output = "beryl:beryl_boots",
	recipe = {
		{"beryl:beryl", "", "beryl:beryl"},
		{"beryl:beryl", "", "beryl:beryl"}
	},
})

-- Armor
if minetest.get_modpath("3d_armor") then
	armor:register_armor("beryl:beryl_helmet", {
		description = ("Beryl Helmet"),
		inventory_image = "beryl_beryl_helmet_inv.png",
		groups = {armor_head=1, armor_heal=15, armor_use=175, armor_fire=1},
		armor_groups = {fleshy=13},
		damage_groups = {cracky=2, choppy=1, level=10},
	})

	armor:register_armor("beryl:beryl_chestplate", {
		description = ("Beryl Chestplate"),
		inventory_image = "beryl_beryl_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=17, armor_use=175, armor_fire=1},
		armor_groups = {fleshy=15},
		damage_groups = {cracky=2, choppy=1, level=12},
	})

	armor:register_armor("beryl:beryl_leggings", {
		description = ("Beryl Leggings"),
		inventory_image = "beryl_beryl_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=16, armor_use=175, armor_fire=1},
		armor_groups = {fleshy=16},
		damage_groups = {cracky=2, choppy=1, level=11},
	})

	armor:register_armor("beryl:beryl_boots", {
		description = ("Beryl Boots"),
		inventory_image = "beryl_beryl_boots_inv.png",
		groups = {armor_feet=1, armor_heal=14, armor_use=175, armor_fire=1, physics_speed=0.25},
		armor_groups = {fleshy=12},
		damage_groups = {cracky=2, choppy=1, level=9},
	})

end