# Authors

## Source code

[ChaosWormz](https://github.com/ChaosWormz) and contributors ([GNU LGPLv2.1+](https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html)).

## Media (textures and sounds)

[David Leal](https://github.com/Panquesito7) ([CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)):

- [`tpr_warp.ogg`](https://github.com/minetest-mods/teleport-request/blob/HEAD/sounds/tpr_warp.ogg)

[Robbie Ferguson](https://github.com/Cat5TV) ([CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)):

- [`tpr_portal_parti.png`](https://github.com/minetest-mods/teleport-request/blob/HEAD/textures/tpr_portal_parti.png)
