-----------------
-- Ores/Blocks --
-----------------
minetest.register_node("synlium:synlium_block", {
	description = ("Synlium Block"),
	tiles = {"synlium_synlium_block.png"},
	is_ground_content = true,
	groups = {cracky = 2, level = 2},
	sounds = default.node_sound_metal_defaults(),
})

minetest.register_node("synlium:synlium_ore", {
	description = ("Synlium Ore"),
	tiles = {"default_stone.png^synlium_synlium_ore.png"},
	groups = {cracky = 2, level = 2},
	sounds = default.node_sound_stone_defaults(),
	drop = "synlium:synlium_lump",
})

-----------
-- Tools --
-----------
minetest.register_tool("synlium:synlium_sword", {
	description = ("Synlium Sword"),
	inventory_image = "synlium_synlium_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.70, [2]=0.6, [3]=0.4}, uses=50, maxlevel=3},
		},
		damage_groups = {fleshy=8.5},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("synlium:synlium_pickaxe", {
	description = ("Synlium Pickaxe"),
	inventory_image = "synlium_synlium_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			cracky={times={[1]=0.70, [2]=0.6, [3]=0.4}, uses=50, maxlevel=3},
		},
		damage_groups = {fleshy=6},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1}
})

minetest.register_tool("synlium:synlium_axe", {
	description = ("Synlium Axe"),
	inventory_image = "synlium_synlium_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=0.70, [2]=0.6, [3]=0.4}, uses=50, maxlevel=3},
		},
		damage_groups = {fleshy=7},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {axe = 1},
})

minetest.register_tool("synlium:synlium_shovel", {
	description = ("Synlium Shovel"),
	inventory_image = "synlium_synlium_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			crumbly={times={[1]=0.7, [2]=0.6, [3]=0.4}, uses = 50, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel =1},
})

------------
-- Mapgen --
------------

-- Synlium Ore

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "synlium:synlium_ore",
		wherein        = "default:stone",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 3,
		clust_size     = 2,
		y_max          = -1250,
		y_min          = -25000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "synlium:synlium_ore",
		wherein        = "default:stone",
		clust_scarcity = 17 * 17 * 17,
		clust_num_ores = 5,
		clust_size     = 6,
		y_max          = -2700,
		y_min          = -31000,
	})
-----------------
-- Craft Items --
-----------------
minetest.register_craftitem("synlium:synlium_lump", {
	description = ("Synlium Lump"),
	inventory_image = "synlium_synlium_lump.png"
})

minetest.register_craftitem("synlium:synlium_ingot", {
	description = ("Synlium Ingot"),
	inventory_image = "synlium_synlium_ingot.png"
})

------------
-- Crafts --
------------

-- Block
minetest.register_craft({
	output = "synlium:synlium_block",
	recipe = {
		{"synlium:synlium_ingot", "synlium:synlium_ingot", "synlium:synlium_ingot"},
		{"synlium:synlium_ingot", "synlium:synlium_ingot", "synlium:synlium_ingot"},
		{"synlium:synlium_ingot", "synlium:synlium_ingot", "synlium:synlium_ingot"},
	},
})

minetest.register_craft({
	output = "synlium:synlium_ingot 9",
	recipe = {
		{"synlium:synlium_block"},
	},
})

-- Smelting Recipe
minetest.register_craft({
	type = "cooking",
	output = "synlium:synlium_ingot",
	recipe = "synlium:synlium_lump",
})

-- Tools

minetest.register_craft({
	output = "synlium:synlium_sword",
	recipe = {
		{"synlium:synlium_ingot"},
		{"synlium:synlium_ingot"},
		{"group:stick"},
	},
})

minetest.register_craft({
	output = "synlium:synlium_pickaxe",
	recipe = {
		{"synlium:synlium_ingot", "synlium:synlium_ingot", "synlium:synlium_ingot"},
		{"", "group:stick", ""},
		{"", "group:stick", ""},
	},
})

minetest.register_craft({
	output = "synlium:synlium_axe",
	recipe = {
		{"synlium:synlium_ingot", "synlium:synlium_ingot", ""},
		{"synlium:synlium_ingot", "group:stick", ""},
		{"", "group:stick", ""},
	},
})

minetest.register_craft({
	output = "synlium:synlium_shovel",
	recipe = {
		{"synlium:synlium_ingot"},
		{"group:stick"},
		{"group:stick"},
	},
})

-- Armor
minetest.register_craft({
	output = "synlium:synlium_helmet",
	recipe = {
		{"synlium:synlium_ingot", "synlium:synlium_ingot", "synlium:synlium_ingot"},
		{"synlium:synlium_ingot", "", "synlium:synlium_ingot"},
		{"", "", ""}
	},
})

minetest.register_craft({
	output = "synlium:synlium_chestplate",
	recipe = {
		{"synlium:synlium_ingot", "", "synlium:synlium_ingot"},
		{"synlium:synlium_ingot", "synlium:synlium_ingot", "synlium:synlium_ingot"},
		{"synlium:synlium_ingot", "synlium:synlium_ingot", "synlium:synlium_ingot"},
	},
})

minetest.register_craft({
	output = "synlium:synlium_leggings",
	recipe = {
		{"synlium:synlium_ingot", "synlium:synlium_ingot", "synlium:synlium_ingot"},
		{"synlium:synlium_ingot", "", "synlium:synlium_ingot"},
		{"synlium:synlium_ingot", "", "synlium:synlium_ingot"},
	},
})

minetest.register_craft({
	output = "synlium:synlium_boots",
	recipe = {
		{"synlium:synlium_ingot", "", "synlium:synlium_ingot"},
		{"synlium:synlium_ingot", "", "synlium:synlium_ingot"},
		{"", "", "",}
	},
})

minetest.register_craft({
	output = "synlium:synlium_shield",
	recipe = {
		{"synlium:synlium_ingot", "synlium:synlium_ingot", "synlium:synlium_ingot"},
		{"synlium:synlium_ingot", "synlium:synlium_ingot", "synlium:synlium_ingot"},
		{"", "synlium:synlium_ingot", ""}
	},
})
----------------------
-- 3D Armor support --
----------------------
if minetest.get_modpath("3d_armor") then
	armor:register_armor("synlium:synlium_helmet", {
		description = ("Synlium Helmet"),
		inventory_image = "synlium_synlium_helmet_inv.png",
		groups = {armor_head=1, armor_heal=14, armor_use=190},
		armor_groups = {fleshy=16},
		damage_groups = {cracky=3, snappy=1, choppy=1, level=4},
	})

	armor:register_armor("synlium:synlium_chestplate", {
		description = ("Synlium Chestplate"),
		inventory_image = "synlium_synlium_chestplate_inv.png",
		groups = {armor_torso=1, armor_heal=15, armor_use=190},
		armor_groups = {fleshy=18},
		damage_groups = {cracky=5, snappy=3, level=5},
	})

	armor:register_armor("synlium:synlium_leggings", {
		description = ("Synlium Leggings"),
		inventory_image = "synlium_synlium_leggings_inv.png",
		groups = {armor_legs=1, armor_heal=15, armor_use=190},
		armor_groups = {fleshy=17},
		damage_groups = {cracky=4, snappy=2, level=5},
	})

	armor:register_armor("synlium:synlium_boots", {
		description = ("Synlium Boots"),
		inventory_image = "synlium_synlium_boots_inv.png",
		groups = {armor_feet=1, armor_heal=14, armor_use=190},
		armor_groups = {fleshy=14},
		damage_groups = {cracky=2, snappy=1, level=4},
	})

	armor:register_armor("synlium:synlium_shield", {
		description = ("Synlium Shield"),
		inventory_image = "synlium_synlium_shield_inv.png",
		groups = {armor_shield=1, armor_heal=15, armor_use=190},
		armor_groups = {fleshy=16},
		damage_groups = {cracky=3, snappy=2, choppy=2, level=5},
	})
end