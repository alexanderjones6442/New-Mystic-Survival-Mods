Minetest mod: spawn

========================
See license.txt for license information.

Authors of source code
----------------------
paramat (MIT)
cathaya7d4 (MIT)
