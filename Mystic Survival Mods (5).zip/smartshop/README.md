# smartshop
mod for minetest

Licenses: code: LGPL-2.1, media: CC BY-SA-4.0

Version: 7.11

Like the title says, this is a smart and easy shop, that will also fit everywhere.

it is a mix of a vending machine, a shop, item frames and light.

You can toogle it unlimited or limited if you have give or creative
(unlimited will not take or add stuff to its inventory)

The "All" button will limit your stock to the inventory or and the giveline, its on as default.

wifi storage, send to and refill from wifi storages

It also works with pipeworks, mesecon and aliveai
